﻿Public Class frmclientenuevo
    Sub MostrarLugares()
        CboLugares.Items.Clear()
        Abrir()
        cmd.CommandText = "Select Nombre From Lugares Order By Nombre"
        dr = cmd.ExecuteReader
        While dr.Read
            CboLugares.Items.Add(dr("Nombre"))
        End While
        Cerrar()
    End Sub

    Sub SoloLetras(ByRef e As System.Windows.Forms.KeyPressEventArgs)
        If Char.IsDigit(e.KeyChar) Then
            e.Handled = True
            MsgBox("Solo se puede ingresar valores de tipo texto", MsgBoxStyle.Exclamation, "Ingreso de Texto")
        ElseIf Char.IsControl(e.KeyChar) Then
            e.Handled = False
        Else
            e.Handled = False
        End If
    End Sub

    Sub SoloNumeros(ByRef e As System.Windows.Forms.KeyPressEventArgs)
        If Char.IsDigit(e.KeyChar) Then
            e.Handled = False
        ElseIf Char.IsControl(e.KeyChar) Then
            e.Handled = False
        Else
            e.Handled = True
            MsgBox("Solo se puede ingresar valores de tipo número", MsgBoxStyle.Exclamation, "Ingreso de Número")
        End If
    End Sub

    Private Sub frmclientenuevo_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        MostrarLugares()
    End Sub

    Private Sub BtnGrabar_Click(sender As Object, e As EventArgs) Handles BtnGrabar.Click
        Dim CodLugar As Integer
        Abrir()
        cmd.CommandText = "Select Codigo From Lugares Where Nombre='" & CboLugares.Text & "'"
        dr = cmd.ExecuteReader
        If dr.Read Then
            CodLugar = dr("Codigo")
            dr.Close()
        Else
            Cerrar()
            MsgBox("El Lugar no existe", 16, "Aviso")
            Exit Sub
        End If
        cmd.CommandText = "Insert Into Clientes (Dni,Ruc,Apaterno,AMaterno,Nombre01,Nombre02,Celular,Correo,Direccion,CodLugar)" _
            & " Values('" & TxtDni.Text & "','" & TxtRuc.Text & "','" & TxtApaterno.Text & "','" & _
           TxtAMaterno.Text & "','" & TxtNombre01.Text & "','" & TxtNombre02.Text & "','" & TxtCelular.Text & "','" & _
           TxtCorreo.Text & "','" & TxtDireccion.Text & "'," & CodLugar & ")"
        cmd.ExecuteNonQuery()
        Cerrar()
        If TxtDni.Text = "" Then
            frmventas.txtdocumento.Text = TxtRuc.Text
        Else
            frmventas.txtdocumento.Text = TxtDni.Text
        End If

        frmventas.cboclientes.Text = TxtApaterno.Text & " " & TxtAMaterno.Text & " " & TxtNombre01.Text & " " & TxtNombre02.Text
        Close()
    End Sub

    Private Sub BtnCerrar_Click(sender As Object, e As EventArgs) Handles BtnCerrar.Click
        Close()
    End Sub

    Private Sub TxtDni_KeyPress(sender As Object, e As KeyPressEventArgs) Handles TxtDni.KeyPress
        If Asc(e.KeyChar) = 13 Then
            TxtRuc.Focus()
        End If
        SoloNumeros(e)
    End Sub

    Private Sub TxtRuc_KeyPress(sender As Object, e As KeyPressEventArgs) Handles TxtRuc.KeyPress
        If Asc(e.KeyChar) = 13 Then
            TxtApaterno.Focus()
        End If
        SoloNumeros(e)
    End Sub

    Private Sub TxtApaterno_KeyPress(sender As Object, e As KeyPressEventArgs) Handles TxtApaterno.KeyPress
        If Asc(e.KeyChar) = 13 Then
            TxtAMaterno.Focus()
        End If
        SoloLetras(e)
    End Sub

    Private Sub TxtAMaterno_KeyPress(sender As Object, e As KeyPressEventArgs) Handles TxtAMaterno.KeyPress
        If Asc(e.KeyChar) = 13 Then
            TxtNombre01.Focus()
        End If
        SoloLetras(e)
    End Sub

    Private Sub TxtNombre01_KeyPress(sender As Object, e As KeyPressEventArgs) Handles TxtNombre01.KeyPress
        If Asc(e.KeyChar) = 13 Then
            TxtNombre02.Focus()
        End If
        SoloLetras(e)
    End Sub

    Private Sub TxtNombre02_KeyPress(sender As Object, e As KeyPressEventArgs) Handles TxtNombre02.KeyPress
        If Asc(e.KeyChar) = 13 Then
            TxtCelular.Focus()
        End If
        SoloLetras(e)
    End Sub

    Private Sub TxtCelular_KeyPress(sender As Object, e As KeyPressEventArgs) Handles TxtCelular.KeyPress
        If Asc(e.KeyChar) = 13 Then
            TxtCorreo.Focus()
        End If
    End Sub

    Private Sub TxtCorreo_KeyPress(sender As Object, e As KeyPressEventArgs) Handles TxtCorreo.KeyPress
        If Asc(e.KeyChar) = 13 Then
            TxtDireccion.Focus()
        End If
    End Sub

    Private Sub TxtDireccion_KeyPress(sender As Object, e As KeyPressEventArgs) Handles TxtDireccion.KeyPress
        If Asc(e.KeyChar) = 13 Then
            CboLugares.Focus()
        End If
    End Sub

    Private Sub CboLugares_KeyPress(sender As Object, e As KeyPressEventArgs) Handles CboLugares.KeyPress
        If Asc(e.KeyChar) = 13 Then
            BtnGrabar.Focus()
        End If
        SoloLetras(e)
    End Sub
End Class