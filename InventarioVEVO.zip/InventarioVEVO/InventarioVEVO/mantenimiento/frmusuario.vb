﻿Public Class frmusuario
    Sub limpiar()
        lblcodigo.Text = ""
        txtnombres.Text = ""
        txtusuario.Text = ""
        txtclave.Text = ""
        cbonivel.Text = ""
    End Sub
    Sub mostrarusuario()
        cbousuarios.Items.Clear()
        Abrir()
        Cmd.CommandText = "select nomcompleto from usuario"
        Dr = Cmd.ExecuteReader
        While Dr.Read
            cbousuarios.Items.Add(dr("nomcompleto"))
        End While
        Cerrar()
    End Sub
    Private Sub frmusuario_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        mostrarusuario()
    End Sub

    Private Sub cbousuarios_SelectedIndexChanged(sender As Object, e As EventArgs) Handles cbousuarios.SelectedIndexChanged
        Abrir()
        cmd.CommandText = "select * from usuario where nomcompleto='" & cbousuarios.Text & "'"
        dr = cmd.ExecuteReader
        If dr.Read Then
            lblcodigo.Text = dr("idusuario")
            txtnombres.Text = dr("nomcompleto")
            txtusuario.Text = dr("nomusuario")
            txtclave.Text = desencriptar(dr("clave"))
            cbonivel.Text = dr("nivel")
        Else
            limpiar()
        End If
        Cerrar()
    End Sub

    Private Sub btngrabar_Click(sender As Object, e As EventArgs) Handles btngrabar.Click
        Abrir()
        If Val(lblcodigo.Text) = 0 Then
            cmd.CommandText = "insert into usuario (nomcompleto,nomusuario,clave,nivel,estado) Values ('" & txtnombres.Text & "','" & txtusuario.Text & "','" & encriptar(txtclave.Text) & "','" & cbonivel.Text & "','A')"
        Else
            cmd.CommandText = "update usuario set nomcompleto='" & txtnombres.Text & "',nomusuario='" & txtusuario.Text & "',clave='" & encriptar(txtclave.Text) & "',nivel='" & cbonivel.Text & "',estado='A' Where idusuario=" & Val(lblcodigo.Text)
        End If
        cmd.ExecuteNonQuery()
        Cerrar()
        If Val(lblcodigo.Text) = 0 Then
            MsgBox("Los datos se agregaron correctamente", 64, "Aviso")
            limpiar()
        Else
            MsgBox("Los datos se actualizaron correctamente", 64, "Aviso")
        End If
        mostrarusuario()
    End Sub

    Private Sub btnnuevo_Click(sender As Object, e As EventArgs) Handles btnnuevo.Click
        limpiar()
    End Sub
End Class