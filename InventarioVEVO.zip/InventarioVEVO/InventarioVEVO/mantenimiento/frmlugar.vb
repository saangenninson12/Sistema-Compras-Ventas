﻿Public Class frmlugar
    Sub mostrarlugar()
        cbolugar.Items.Clear()
        Abrir()
        cmd.CommandText = "select nombre from lugares"
        dr = cmd.ExecuteReader
        While dr.Read
            cbolugar.Items.Add(dr("nombre"))
        End While
        Cerrar()
    End Sub

    Private Sub frmlugar_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        mostrarlugar()
    End Sub

    Private Sub btnguardar_Click(sender As Object, e As EventArgs) Handles btnguardar.Click
        If txtnombre.Text = "" Then
            MsgBox("Ingrese el nombre del lugar", 16, "Dato obligatorio")
            txtnombre.Focus()
            Exit Sub
        End If
        Abrir()
        If Val(lblcodigo.Text) = 0 Then
            cmd.CommandText = "insert into lugares (nombre,estado) Values ('" & txtnombre.Text & "','A')"
        Else
            cmd.CommandText = "update lugares set nombre='" & txtnombre.Text & "',estado='A' Where codigo=" & Val(lblcodigo.Text)
        End If
        cmd.ExecuteNonQuery()
        Cerrar()
        If Val(lblcodigo.Text) = 0 Then
            MsgBox("Los datos se agregaron correctamente", 64, "Aviso")
            txtnombre.Text = ""
        Else
            MsgBox("Los datos se actualizaron correctamente", 64, "Aviso")
        End If
        mostrarlugar()
    End Sub

    Private Sub cbolugar_SelectedIndexChanged(sender As Object, e As EventArgs) Handles cbolugar.SelectedIndexChanged
        Abrir()
        cmd.CommandText = "select * from lugares where nombre='" & cbolugar.Text & "'"
        dr = cmd.ExecuteReader
        If dr.Read Then
            lblcodigo.Text = dr("codigo")
            txtnombre.Text = dr("nombre")
        Else
            lblcodigo.Text = ""
            txtnombre.Text = "Datos Incorrectos"
        End If
        Cerrar()
    End Sub

    Private Sub EliminarToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles EliminarToolStripMenuItem.Click
        'Abrir()
        'cmd.CommandText = "delete lugares where codigo=" & cbolugar.Items("codigo")
        'MsgBox("Dato eliminado", 64, "Felicidades")
        'mostrarlugar()
        'Cerrar()
    End Sub

    Private Sub btnNuevo_Click(sender As Object, e As EventArgs) Handles btnNuevo.Click
        lblcodigo.Text = ""
        txtnombre.Text = ""
    End Sub
End Class