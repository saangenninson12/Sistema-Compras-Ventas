﻿Public Class frmcomprobantes
    Sub Limpiar()
        LblCodigo.Text = ""
        TxtNombre.Text = ""
        TxtSerie.Text = ""
        TxtNumero.Text = ""
    End Sub
    Sub MostrarNombres()
        CboComprobantes.Items.Clear()
        Abrir()
        cmd.CommandText = "Select Nombre From Comprobantes Order By Nombre"
        dr = cmd.ExecuteReader
        While dr.Read
            CboComprobantes.Items.Add(dr("Nombre"))
        End While
        Cerrar()
    End Sub

    Sub SoloLetras(ByRef e As System.Windows.Forms.KeyPressEventArgs)
        If Char.IsDigit(e.KeyChar) Then
            e.Handled = True
            MsgBox("Solo se puede ingresar valores de tipo texto", MsgBoxStyle.Exclamation, "Ingreso de Texto")
        ElseIf Char.IsControl(e.KeyChar) Then
            e.Handled = False
        Else
            e.Handled = False
        End If
    End Sub

    Sub SoloNumeros(ByRef e As System.Windows.Forms.KeyPressEventArgs)
        If Char.IsDigit(e.KeyChar) Then
            e.Handled = False
        ElseIf Char.IsControl(e.KeyChar) Then
            e.Handled = False
        Else
            e.Handled = True
            MsgBox("Solo se puede ingresar valores de tipo número", MsgBoxStyle.Exclamation, "Ingreso de Número")
        End If
    End Sub

    Private Sub frmcomprobantes_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        MostrarNombres()
    End Sub

    Private Sub CboComprobantes_SelectedIndexChanged(sender As Object, e As EventArgs) Handles CboComprobantes.SelectedIndexChanged
        Abrir()
        cmd.CommandText = "Select * From Comprobantes Where Nombre='" & CboComprobantes.Text & "'"
        dr = cmd.ExecuteReader
        If dr.Read Then
            LblCodigo.Text = dr("Codigo")
            TxtNombre.Text = dr("Nombre")
            TxtSerie.Text = dr("Serie")
            TxtNumero.Text = dr("Numero")
            If dr("Estado") = "A" Then
                LblAnulado.Visible = False
            Else
                LblAnulado.Visible = True
            End If
        Else
            Limpiar()
        End If
        Cerrar()
    End Sub

    Private Sub BtnGrabar_Click(sender As Object, e As EventArgs) Handles BtnGrabar.Click
        If Trim(lblcodigo.Text) = "" Then
            MsgBox("Ingrese el código de 2 dígitos", 16, "No se puede grabar")
            lblcodigo.Focus()
            Exit Sub
        End If

        If Trim(TxtNombre.Text) = "" Then
            MsgBox("Ingrese el nombre del comprobante", 16, "No se puede grabar")
            TxtNombre.Focus()
            Exit Sub
        End If
        Abrir()
        'If lblcodigo.Text = "" Then
        '    cmd.CommandText = "Insert Into Comprobantes (codigo,Nombre,Serie,Numero) Values('" & Val(lblcodigo.Text) & "','" & TxtNombre.Text & "','" & TxtSerie.Text & "','" & Val(TxtNumero.Text) & "')"
        'Else
        '    cmd.CommandText = "Update Comprobantes Set Nombre='" & TxtNombre.Text & "',Serie='" & TxtSerie.Text & "',Numero=" & Val(TxtNumero.Text) & " Where Codigo='" & lblcodigo.Text & "'"
        'End If
        '---------------------
        If lblcodigo.Text = "" Then
            cmd.CommandText = "Insert Into Comprobantes (Codigo,Nombre,Serie,Numero) Values('" & lblcodigo.Text & "','" & TxtNombre.Text & "','" & TxtSerie.Text & "','" & TxtNumero.Text & "')"
        Else
            cmd.CommandText = "Update Comprobantes Set Codigo='" & lblcodigo.Text & "',Nombre='" & TxtNombre.Text & "',Serie='" & TxtSerie.Text & "',Numero='" & TxtNumero.Text & "' Where Codigo='" & lblcodigo.Text & "' "
        End If
        '-----------------
        cmd.ExecuteNonQuery()
        Cerrar()
        MostrarNombres()
        MsgBox("Los datos se grabaron con éxito", 64, "Aviso")
    End Sub

    Private Sub BtnNuevo_Click(sender As Object, e As EventArgs) Handles BtnNuevo.Click
        Limpiar()
        TxtNombre.Focus()
    End Sub

    Private Sub BtnAnular_Click(sender As Object, e As EventArgs) Handles BtnAnular.Click
        Abrir()
        If LblAnulado.Visible = False Then
            cmd.CommandText = "Update Comprobantes Set Estado='X' Where Codigo=" & Val(LblCodigo.Text)
        Else
            cmd.CommandText = "Update Comprobantes Set Estado='A' Where Codigo=" & Val(LblCodigo.Text)
        End If
        cmd.ExecuteNonQuery()
        Cerrar()
        LblAnulado.Visible = Not LblAnulado.Visible
    End Sub

    Private Sub TxtNombre_KeyPress(sender As Object, e As KeyPressEventArgs) Handles TxtNombre.KeyPress
        If Asc(e.KeyChar) = 13 Then
            TxtSerie.Focus()
        End If
        SoloLetras(e)
    End Sub

    Private Sub TxtSerie_KeyPress(sender As Object, e As KeyPressEventArgs) Handles TxtSerie.KeyPress
        If Asc(e.KeyChar) = 13 Then
            TxtNumero.Focus()
        End If
    End Sub

    Private Sub TxtNumero_KeyPress(sender As Object, e As KeyPressEventArgs) Handles TxtNumero.KeyPress
        If Asc(e.KeyChar) = 13 Then
            BtnGrabar.Focus()
        End If
        SoloNumeros(e)
    End Sub

    Private Sub btnEliminar_Click(sender As Object, e As EventArgs) Handles btnEliminar.Click
        Abrir()
        cmd.CommandText = "delete from comprobantes where codigo = " & Val(lblcodigo.Text)
        cmd.ExecuteNonQuery()
        MsgBox("¿Dato eliminado correctamente", 64, "Felicitaciones")
        Cerrar()
        MostrarNombres()
    End Sub
End Class