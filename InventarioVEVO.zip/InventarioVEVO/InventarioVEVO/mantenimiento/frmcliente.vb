﻿Public Class frmcliente
    Sub titulo()
        dg.ColumnCount = 0
        dg.Columns.Add("codigo", "idcliente")
        dg.Columns.Add("numero", "Nº")
        dg.Columns.Add("dni", "Dni")
        dg.Columns.Add("ruc", "Ruc")
        dg.Columns.Add("nombres", "Nombres")
        dg.Columns.Add("celular", "Celular")
        dg.Columns.Add("correo", "Correo")
        dg.Columns.Add("direccion", "Dirección")
        dg.Columns.Add("nomlugar", "Lugar")
        dg.Columns.Add("estado", "E")

        dg.Columns("numero").Width = 30
        dg.Columns("dni").Width = 100
        dg.Columns("ruc").Width = 120
        dg.Columns("nombres").Width = 200
        dg.Columns("celular").Width = 100
        dg.Columns("correo").Width = 150
        dg.Columns("direccion").Width = 150
        dg.Columns("nomlugar").Width = 100
        dg.Columns("estado").Width = 50

        dg.Columns("numero").DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter
        dg.Columns("dni").DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter
        dg.Columns("ruc").DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter
        'dg.Columns("total").DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight
        dg.Columns("estado").DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter

        dg.Columns("codigo").Visible = False
    End Sub
    Sub MostrarLugares()
        CboLugares.Items.Clear()
        Abrir()
        cmd.CommandText = "Select nombre From lugares Order By nombre"
        dr = cmd.ExecuteReader
        While dr.Read
            CboLugares.Items.Add(dr("nombre"))
        End While
        Cerrar()
    End Sub
    Sub mostrar()
        titulo()
        Abrir()
        cmd.CommandText = "select * from clientes_V order by nombre"
        dr = cmd.ExecuteReader
        While dr.Read
            dg.Rows.Add(dr("codigo"), dg.RowCount + 1, dr("dni"), dr("ruc"), dr("nombre"), dr("celular"), dr("correo"), dr("direccion"), dr("lugar"), dr("estado"))
        End While
        Cerrar()
    End Sub
    Sub limpiar()
        txtcodigo.Text = ""
        TxtDni.Text = ""
        TxtRuc.Text = ""
        TxtApaterno.Text = ""
        TxtAMaterno.Text = ""
        TxtNombre01.Text = ""
        TxtNombre02.Text = ""
        TxtCelular.Text = ""
        TxtCorreo.Text = ""
        TxtDireccion.Text = ""
        CboLugares.Text = ""
    End Sub
    Private Sub frmcliente_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        mostrar()
        MostrarLugares()
    End Sub

    Private Sub BtnGrabar_Click(sender As Object, e As EventArgs) Handles BtnGrabar.Click
        Dim CodLugar As Integer
        Abrir()
        cmd.CommandText = "Select codigo From lugares Where nombre='" & CboLugares.Text & "'"
        dr = cmd.ExecuteReader
        If dr.Read Then
            CodLugar = dr("codigo")
            dr.Close()
        Else
            Cerrar()
            MsgBox("El Lugar no existe", 16, "Aviso")
            Exit Sub
        End If


        If Val(txtcodigo.Text) = 0 Then
            cmd.CommandText = "Insert Into Clientes (Dni,Ruc,Apaterno,AMaterno,Nombre01,Nombre02,Celular,Correo,Direccion,codlugar,estado)" _
            & " Values('" & TxtDni.Text & "','" & TxtRuc.Text & "','" & TxtApaterno.Text & "','" & _
           TxtAMaterno.Text & "','" & TxtNombre01.Text & "','" & TxtNombre02.Text & "','" & TxtCelular.Text & "','" & _
           TxtCorreo.Text & "','" & TxtDireccion.Text & "'," & CodLugar & ",'A')"
        Else
            cmd.CommandText = "Update Clientes set Dni='" & TxtDni.Text & "',Ruc='" & TxtRuc.Text & "',Apaterno='" & TxtApaterno.Text & "',AMaterno='" & TxtAMaterno.Text & "', " & _
                "Nombre01='" & TxtNombre01.Text & "',Nombre02='" & TxtNombre02.Text & "',Celular='" & TxtCelular.Text & "',Correo='" & TxtCorreo.Text & "',Direccion='" & TxtDireccion.Text & "',codlugar=" & CodLugar & ",estado='A' where codigo='" & txtcodigo.Text & "'"
        End If
        cmd.ExecuteNonQuery()
        Cerrar()


        If Val(txtcodigo.Text) = 0 Then
            MsgBox("Los datos se agregaron correctamente", 64, "Aviso")
            limpiar()
        Else
            MsgBox("Los datos se actualizaron correctamente", 64, "Aviso")
        End If
        mostrar()
    End Sub

    Private Sub dg_Click(sender As Object, e As EventArgs) Handles dg.Click
        Abrir()
        cmd.CommandText = "select * from clientesVV where codigo=" & dg.CurrentRow.Cells("codigo").Value
        dr = cmd.ExecuteReader
        If dr.Read Then
            txtcodigo.Text = dr("codigo")
            TxtDni.Text = dr("dni")
            TxtRuc.Text = dr("ruc")
            TxtApaterno.Text = dr("apaterno")
            TxtAMaterno.Text = dr("amaterno")
            TxtNombre01.Text = dr("nombre01")
            TxtNombre02.Text = dr("nombre02")
            TxtCelular.Text = dr("celular")
            TxtCorreo.Text = dr("correo")
            TxtDireccion.Text = dr("direccion")
            CboLugares.Text = dr("lugar")
        Else
            limpiar()
        End If
        Cerrar()
    End Sub

    Private Sub btnnuevo_Click(sender As Object, e As EventArgs) Handles btnnuevo.Click
        limpiar()
    End Sub

    Sub SoloLetras(ByRef e As System.Windows.Forms.KeyPressEventArgs)
        'Activamos la alerta para que no tenga el error al guardar
        If Char.IsDigit(e.KeyChar) Then
            e.Handled = True
            MsgBox("Solo se puede ingresar valores de tipo texto", MsgBoxStyle.Exclamation, "Ingreso de Texto")
        ElseIf Char.IsControl(e.KeyChar) Then
            e.Handled = False
        Else
            e.Handled = False
        End If
    End Sub

    Sub SoloNumeros(ByRef e As System.Windows.Forms.KeyPressEventArgs)
        If Char.IsDigit(e.KeyChar) Then
            e.Handled = False
        ElseIf Char.IsControl(e.KeyChar) Then
            e.Handled = False
        Else
            e.Handled = True
            MsgBox("Solo se puede ingresar valores de tipo número", MsgBoxStyle.Exclamation, "Ingreso de Número")
        End If
    End Sub

    Private Sub TxtDni_KeyPress(sender As Object, e As KeyPressEventArgs) Handles TxtDni.KeyPress
        If Asc(e.KeyChar) = 13 Then
            TxtRuc.Focus()
        End If
        SoloNumeros(e)
    End Sub

    Private Sub TxtRuc_KeyPress(sender As Object, e As KeyPressEventArgs) Handles TxtRuc.KeyPress
        If Asc(e.KeyChar) = 13 Then
            TxtApaterno.Focus()
        End If
        SoloNumeros(e)
    End Sub

    Private Sub TxtApaterno_KeyPress(sender As Object, e As KeyPressEventArgs) Handles TxtApaterno.KeyPress
        If Asc(e.KeyChar) = 13 Then
            TxtAMaterno.Focus()
        End If
        SoloLetras(e)
    End Sub

    Private Sub TxtAMaterno_KeyPress(sender As Object, e As KeyPressEventArgs) Handles TxtAMaterno.KeyPress
        If Asc(e.KeyChar) = 13 Then
            TxtNombre01.Focus()
        End If
        SoloLetras(e)
    End Sub

    Private Sub TxtNombre01_KeyPress(sender As Object, e As KeyPressEventArgs) Handles TxtNombre01.KeyPress
        If Asc(e.KeyChar) = 13 Then
            TxtNombre02.Focus()
        End If
        SoloLetras(e)
    End Sub

    Private Sub TxtNombre02_KeyPress(sender As Object, e As KeyPressEventArgs) Handles TxtNombre02.KeyPress
        If Asc(e.KeyChar) = 13 Then
            TxtCelular.Focus()
        End If
        SoloLetras(e)
    End Sub

    Private Sub TxtCelular_KeyPress(sender As Object, e As KeyPressEventArgs) Handles TxtCelular.KeyPress
        If Asc(e.KeyChar) = 13 Then
            TxtCorreo.Focus()
        End If
    End Sub

    Private Sub TxtCorreo_KeyPress(sender As Object, e As KeyPressEventArgs) Handles TxtCorreo.KeyPress
        If Asc(e.KeyChar) = 13 Then
            TxtDireccion.Focus()
        End If
    End Sub

    Private Sub TxtDireccion_KeyPress(sender As Object, e As KeyPressEventArgs) Handles TxtDireccion.KeyPress
        If Asc(e.KeyChar) = 13 Then
            CboLugares.Focus()
        End If
    End Sub

    Private Sub CboLugares_KeyPress(sender As Object, e As KeyPressEventArgs) Handles CboLugares.KeyPress
        If Asc(e.KeyChar) = 13 Then
            BtnGrabar.Focus()
        End If
        SoloLetras(e)
    End Sub

    Private Sub txtbuscar_KeyPress(sender As Object, e As KeyPressEventArgs)
        SoloNumeros(e)
    End Sub

    Private Sub btnEliminar_Click(sender As Object, e As EventArgs) Handles btnEliminar.Click
        Abrir()
        cmd.CommandText = "delete clientes where codigo='" & txtcodigo.Text & "'"
        cmd.ExecuteNonQuery()
        MsgBox("Se eliminó correctamente", 64, "Felicitaciones")
        Cerrar()
        mostrar()
        limpiar()
    End Sub
End Class