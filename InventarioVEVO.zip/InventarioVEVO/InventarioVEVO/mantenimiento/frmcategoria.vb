﻿Public Class frmcategoria
    Sub MostrarCategorias()
        Dg.ColumnCount = 0
        Dg.Columns.Add("codigo", "idcategoria")
        Dg.Columns.Add("Numero", "Nº")
        Dg.Columns.Add("nombre", "Categoría")
        Dg.Columns.Add("estado", "Estado")

        Dg.Columns("Numero").Width = 50
        Dg.Columns("nombre").Width = 250
        Dg.Columns("Numero").DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter
        Dg.Columns("estado").DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter
        Dg.Columns("codigo").Visible = False

        Dim Estado As String
        Abrir()
        cmd.CommandText = "Select * From categorias Order By nombre"
        dr = cmd.ExecuteReader
        While dr.Read
            If dr("estado") = "A" Then
                Estado = ""
            Else
                Estado = "Anulado"
            End If
            Dg.Rows.Add(dr("codigo"), Dg.RowCount + 1, dr("nombre"), Estado)
        End While
        Cerrar()
    End Sub
    Private Sub frmcategoria_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        MostrarCategorias()
    End Sub

    Sub SoloLetras(ByRef e As System.Windows.Forms.KeyPressEventArgs)
        If Char.IsDigit(e.KeyChar) Then
            e.Handled = True
            MsgBox("Solo se puede ingresar valores de tipo texto", MsgBoxStyle.Exclamation, "Ingreso de Texto")
        ElseIf Char.IsControl(e.KeyChar) Then
            e.Handled = False
        Else
            e.Handled = False
        End If
    End Sub

    Private Sub NuevoToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles NuevoToolStripMenuItem.Click
        Dim Nombre As String
        Nombre = InputBox("Nombre", "Nueva Categoria")
        If Nombre <> "" Then
            Abrir()
            cmd.CommandText = "Insert Into categorias (nombre,estado) Values('" & Nombre & "','A')"
            cmd.ExecuteNonQuery()
            Cerrar()
            MostrarCategorias()
        End If
    End Sub

    Private Sub ActualizarToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles ActualizarToolStripMenuItem.Click
        Dim Nombre As String
        Nombre = InputBox("Nombre", "Nueva Categoria", Dg.CurrentRow.Cells("nomcategoria").Value)
        If Nombre <> "" Then
            Abrir()
            cmd.CommandText = "Update categorias Set nombre='" & Nombre & "' Where codigo=" & Dg.CurrentRow.Cells("codigo").Value
            cmd.ExecuteNonQuery()
            Cerrar()
            MostrarCategorias()
        End If
    End Sub

    Private Sub AnularToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles AnularToolStripMenuItem.Click
        Abrir()
        cmd.CommandText = "Update categorias Set estado='X' Where codigo=" & Dg.CurrentRow.Cells("codigo").Value
        cmd.ExecuteNonQuery()
        Cerrar()
        MostrarCategorias()
    End Sub

    Private Sub RestaurarToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles RestaurarToolStripMenuItem.Click
        Abrir()
        cmd.CommandText = "Update categorias Set estado='A' Where codigo=" & Dg.CurrentRow.Cells("codigo").Value
        cmd.ExecuteNonQuery()
        Cerrar()
        MostrarCategorias()
    End Sub

    Private Sub BtnCerrar_Click(sender As Object, e As EventArgs)
        Close()
    End Sub
End Class