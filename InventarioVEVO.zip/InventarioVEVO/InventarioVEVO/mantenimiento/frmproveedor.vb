﻿Public Class frmproveedor
    Sub limpiar()
        lblcodigo.Text = ""
        txtdniruc.Text = ""
        txtrazonsocial.Text = ""
        txtdireccion.Text = ""
        txttelefono.Text = ""
        txtdniruc.Focus()
    End Sub

    Sub mostrarproveedor()
        cboproveedor.Items.Clear()
        Abrir()
        cmd.CommandText = "select * from proveedores"
        dr = cmd.ExecuteReader
        While dr.Read
            cboproveedor.Items.Add(dr("razonsocial"))
        End While
        Cerrar()
    End Sub

    Private Sub frmproveedor_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        mostrarproveedor()
    End Sub

    Private Sub btnnuevo_Click(sender As Object, e As EventArgs) Handles btnnuevo.Click
        limpiar()
    End Sub

    Private Sub cboproveedor_SelectedIndexChanged(sender As Object, e As EventArgs) Handles cboproveedor.SelectedIndexChanged
        Abrir()
        cmd.CommandText = "select * from proveedores where razonsocial = '" & cboproveedor.Text & "'"
        dr = cmd.ExecuteReader
        If dr.Read Then
            lblcodigo.Text = dr("codigo")
            txtdniruc.Text = dr("dniruc")
            txtrazonsocial.Text = dr("razonsocial")
            txtdireccion.Text = dr("direccion")
            txttelefono.Text = dr("telefono")
        Else
            limpiar()
        End If
        Cerrar()
    End Sub

    Private Sub BtnGrabar_Click(sender As Object, e As EventArgs) Handles BtnGrabar.Click
        If txtdniruc.Text = "" Then
            MsgBox("Ingrese el dato", 16, "Aviso")
            Exit Sub
        End If
        Abrir()
        If Val(lblcodigo.Text) = 0 Then
            cmd.CommandText = "insert into proveedores (dniruc,razonsocial,direccion,telefono) Values ('" & txtdniruc.Text & "','" & txtrazonsocial.Text & "','" & txtdireccion.Text & "','" & txttelefono.Text & "')"
        Else
            cmd.CommandText = "update proveedores set dniruc='" & txtdniruc.Text & "',razonsocial='" & txtrazonsocial.Text & "',direccion='" & txtdireccion.Text & "',telefono='" & txttelefono.Text & "' Where codigo=" & Val(lblcodigo.Text)
        End If
        cmd.ExecuteNonQuery()
        Cerrar()
        If Val(lblcodigo.Text) = 0 Then
            MsgBox("Los datos se agregaron correctamente", 64, "Aviso")
            limpiar()
        Else
            MsgBox("Los datos se actualizaron correctamente", 64, "Aviso")
        End If
        mostrarproveedor()
    End Sub

    Private Sub btnEliminar_Click(sender As Object, e As EventArgs) Handles btnEliminar.Click
        Abrir()
        cmd.CommandText = "delete from proveedores where codigo='" & lblcodigo.Text & "'"
        cmd.ExecuteNonQuery()
        MsgBox("Se eliminó con éxito", 64, "Aviso")
        Cerrar()
        mostrarproveedor()
        limpiar()
    End Sub
End Class