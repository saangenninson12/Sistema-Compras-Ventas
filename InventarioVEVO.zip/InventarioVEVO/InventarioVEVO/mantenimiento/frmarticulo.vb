﻿Public Class frmarticulo
    Sub Limpiar()
        LblCodigo.Text = ""
        TxtNombre.Text = ""
        CboCategorias.SelectedIndex = -1
        TxtCosto.Text = ""
        TxtPrecio.Text = ""
        TxtStock.Text = ""
    End Sub
    Sub MostrarNombres()
        CboArticulos.Items.Clear()
        Abrir()
        cmd.CommandText = "Select nombre From articulos Order By nombre"
        dr = cmd.ExecuteReader
        While dr.Read
            CboArticulos.Items.Add(dr("nombre"))
        End While
        Cerrar()
    End Sub

    Sub MostrarCategorias()
        CboCategorias.Items.Clear()
        Abrir()
        cmd.CommandText = "Select nombre From categorias Order By nombre"
        dr = cmd.ExecuteReader
        While dr.Read
            CboCategorias.Items.Add(dr("nombre"))
        End While
        Cerrar()
    End Sub
    Private Sub frmarticulo_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        MostrarNombres()
        MostrarCategorias()
    End Sub

    Private Sub CboArticulos_SelectedIndexChanged(sender As Object, e As EventArgs) Handles CboArticulos.SelectedIndexChanged
        Abrir()
        cmd.CommandText = "Select * From articulos_V Where nombre='" & CboArticulos.Text & "'"
        dr = cmd.ExecuteReader
        If dr.Read Then
            LblCodigo.Text = dr("codigo")
            TxtNombre.Text = dr("nombre")
            CboCategorias.Text = dr("categoria")
            TxtCosto.Text = Format(dr("Precio"), "##0.00")
            TxtPrecio.Text = Format(dr("Costo"), "##0.00")
            TxtStock.Text = Val(dr("Stock"))
        Else
            Limpiar()
        End If
        Cerrar()
    End Sub

    Private Sub BtnGrabar_Click(sender As Object, e As EventArgs) Handles BtnGrabar.Click
        Dim CodCategoria As Integer
        Abrir()
        'Busca el codigo de la categoria
        cmd.CommandText = "Select codigo From Categorias Where nombre='" & CboCategorias.Text & "'"
        dr = cmd.ExecuteReader
        If dr.Read Then
            CodCategoria = dr("codigo")
        Else
            Cerrar()
            MsgBox("La Categoria no existe", 16, "Verifique")
            Exit Sub
        End If
        dr.Close()
        If Val(LblCodigo.Text) = 0 Then
            cmd.CommandText = "Insert Into Articulos (nombre,codcategoria,Costo,Precio,Stock) Values('" & TxtNombre.Text & "'," & CodCategoria & "," & Val(TxtCosto.Text) & "," & Val(TxtPrecio.Text) & "," & Val(TxtStock.Text) & ")"
        Else
            cmd.CommandText = "Update Articulos Set nombre='" & TxtNombre.Text & "',codcategoria=" & CodCategoria & ",Costo=" & Val(TxtCosto.Text) & ",Precio=" & Val(TxtPrecio.Text) & ",Stock=" & Val(TxtStock.Text) & " Where codigo=" & Val(LblCodigo.Text)
        End If
        cmd.ExecuteNonQuery()
        Cerrar()
        If Val(LblCodigo.Text) = 0 Then
            MsgBox("Los datos se agregaron correctamente", 64, "Aviso")
        Else
            MsgBox("Los datos se actualizaron correctamente", 64, "Aviso")
        End If
        MostrarNombres()
    End Sub

    'Sub SoloLetras(ByRef e As System.Windows.Forms.KeyPressEventArgs)
    '    If Char.IsDigit(e.KeyChar) Then
    '        e.Handled = True
    '        MsgBox("Solo se puede ingresar valores de tipo texto", MsgBoxStyle.Exclamation, "Ingreso de Texto")
    '    ElseIf Char.IsControl(e.KeyChar) Then
    '        e.Handled = False
    '    Else
    '        e.Handled = False
    '    End If
    'End Sub

    Sub SoloNumeros(ByRef e As System.Windows.Forms.KeyPressEventArgs)
        If Char.IsDigit(e.KeyChar) Then
            e.Handled = False
        ElseIf Char.IsControl(e.KeyChar) Then
            e.Handled = False
        Else
            e.Handled = True
            MsgBox("Solo se puede ingresar valores de tipo número", MsgBoxStyle.Exclamation, "Ingreso de Número")
        End If
    End Sub

    Private Sub BtnNuevo_Click(sender As Object, e As EventArgs) Handles BtnNuevo.Click
        Limpiar()
        TxtNombre.Focus()
    End Sub

    Private Sub CboCategorias_KeyPress(sender As Object, e As KeyPressEventArgs) Handles CboCategorias.KeyPress
        If Asc(e.KeyChar) = 13 Then
            TxtCosto.Focus()
        End If
    End Sub

    Private Sub TxtCosto_KeyPress(sender As Object, e As KeyPressEventArgs) Handles TxtCosto.KeyPress
        If Asc(e.KeyChar) = 13 Then
            TxtPrecio.Focus()
        End If
        SoloNumeros(e)
    End Sub

    Private Sub TxtPrecio_KeyPress(sender As Object, e As KeyPressEventArgs) Handles TxtPrecio.KeyPress
        If Asc(e.KeyChar) = 13 Then
            TxtStock.Focus()
        End If
        SoloNumeros(e)
    End Sub

    Private Sub TxtStock_KeyPress(sender As Object, e As KeyPressEventArgs) Handles TxtStock.KeyPress
        If Asc(e.KeyChar) = 13 Then
            BtnGrabar.Focus()
        End If
        SoloNumeros(e)
    End Sub
End Class