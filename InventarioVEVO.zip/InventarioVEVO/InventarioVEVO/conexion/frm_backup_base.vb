﻿Imports System.Data.SqlClient
Public Class frm_backup_base

    Private Sub btngenerarbackup_Click(sender As Object, e As EventArgs) Handles btngenerarbackup.Click
        Abrir()
        Cmd = New SqlCommand("backup_base")
        Cmd.CommandType = CommandType.StoredProcedure
        Cmd.Connection = Cn
        If Cmd.ExecuteNonQuery Then
            MsgBox("Se generó el Backup con éxito", 64, "Felicidades")
        Else
            Return
        End If
        Cerrar()
    End Sub

    Private Sub frm_backup_base_Load(sender As Object, e As EventArgs) Handles MyBase.Load

    End Sub
End Class