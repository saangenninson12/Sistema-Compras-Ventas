﻿Public Class conectarhora

    Private Sub Timer1_Tick(sender As Object, e As EventArgs) Handles Timer1.Tick
        Me.lblFecha.Text = Now.ToLongDateString
        Me.lblHora.Text = TimeString
    End Sub

    Private Sub conectarhora_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Timer1.Start()
    End Sub

    Private Sub LinkLabel1_LinkClicked(sender As Object, e As LinkLabelLinkClickedEventArgs) Handles LinkLabel1.LinkClicked
        System.Diagnostics.Process.Start("https://inforpetsa.blogspot.com/2019/03/contacto.html")
    End Sub
End Class