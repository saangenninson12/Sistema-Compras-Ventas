﻿Imports System.Runtime.InteropServices
Public Class frmcontenedor

    Private Sub AbrirFormEnPanel(ByVal Formhijo As Object)

        If Me.pnContenedor.Controls.Count > 0 Then Me.pnContenedor.Controls.RemoveAt(0)
        Dim fh As Form = TryCast(Formhijo, Form)
        fh.TopLevel = False
        fh.FormBorderStyle = FormBorderStyle.None
        fh.Dock = DockStyle.Fill
        Me.pnContenedor.Controls.Add(fh)
        Me.pnContenedor.Tag = fh
        fh.Show()
    End Sub

    Private Sub btnCompras_Click(sender As Object, e As EventArgs) Handles btnCompras.Click
        AbrirFormEnPanel(New frmdetalle_compra)
    End Sub

    Private Sub btnListadocompras_Click(sender As Object, e As EventArgs) Handles btnListadocompras.Click
        AbrirFormEnPanel(New frmlistado_compras)
    End Sub

    Private Sub btnVentas_Click(sender As Object, e As EventArgs) Handles btnVentas.Click
        AbrirFormEnPanel(New frmdetalle_venta)
    End Sub

    Private Sub btnListadoventas_Click(sender As Object, e As EventArgs) Handles btnListadoventas.Click
        AbrirFormEnPanel(New frmlistado_ventas)
    End Sub

    Private Sub ptUsuarios_Click(sender As Object, e As EventArgs) Handles ptUsuarios.Click
        AbrirFormEnPanel(New frmusuario)
    End Sub

    Private Sub ptCategoria_Click(sender As Object, e As EventArgs) Handles ptCategoria.Click
        AbrirFormEnPanel(New frmcategoria)
    End Sub

    Private Sub ptComprobante_Click(sender As Object, e As EventArgs) Handles ptComprobante.Click
        AbrirFormEnPanel(New frmcomprobantes)
    End Sub

    Private Sub ptLugar_Click(sender As Object, e As EventArgs) Handles ptLugar.Click
        AbrirFormEnPanel(New frmlugar)
    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        AbrirFormEnPanel(New frmconsulta_general)
    End Sub

    Private Sub frmcontenedor_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        AbrirFormEnPanel(New conectarhora)
    End Sub
End Class