﻿Public Class FrmBarra

    Private Sub Timer1_Tick(sender As Object, e As EventArgs) Handles Timer1.Tick
        If pcargando.Value < 100 Then
            pcargando.Value = pcargando.Value + 10
            lblcargando.Text = "Cargando el sistema al " & pcargando.Value & " %"
        Else
            Timer1.Enabled = False
            Me.Close()
            frmprincipal.Show()
        End If
    End Sub
End Class