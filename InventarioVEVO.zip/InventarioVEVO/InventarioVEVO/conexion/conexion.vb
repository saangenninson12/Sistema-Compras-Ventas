﻿Imports System.Data.SqlClient
Module conexion
    Public cn As New SqlConnection
    Public cmd As New SqlCommand
    Public dr As SqlDataReader

    Public Sub Abrir()
        cn.ConnectionString = "database=MotoRepuestos;Integrated Security=SSPI;Data Source=(Local)"
        cmd.Connection = cn
        cn.Open()
    End Sub

    Public Sub Cerrar()
        cn.Close()
    End Sub

    Public Function encriptar(cadena As String) As String
        Dim letra As String
        Dim n, f As Integer
        letra = ""
        n = cadena.Length
        For f = 1 To n
            letra = letra & Chr(Asc(Mid(cadena, f, 1)) - 11)
        Next
        Return letra
    End Function

    Public Function desencriptar(cadena As String) As String
        Dim letra As String
        Dim n, f As Integer
        letra = ""
        n = cadena.Length
        For f = 1 To n
            letra = letra & Chr(Asc(Mid(cadena, f, 1)) + 11)
        Next
        Return letra
    End Function
End Module
