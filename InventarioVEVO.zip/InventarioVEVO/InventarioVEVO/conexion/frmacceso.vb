﻿Public Class frmacceso

    Private Sub frmacceso_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        txtUsuario.Focus()
    End Sub
    Private Sub txtUsuario_KeyPress(sender As Object, e As KeyPressEventArgs) Handles txtUsuario.KeyPress
        If Asc(e.KeyChar) = 13 Then
            txtClave.Focus()
        End If
    End Sub

    Private Sub txtClave_KeyPress(sender As Object, e As KeyPressEventArgs) Handles txtClave.KeyPress
        If Asc(e.KeyChar) = 13 Then
            btnIngresar.Focus()
        End If
    End Sub

    Private Sub btnCancelar_Click(sender As Object, e As EventArgs) Handles btnCancelar.Click
        Me.Close()
    End Sub

    Private Sub txtUsuario_TextChanged(sender As Object, e As EventArgs) Handles txtUsuario.TextChanged
        txtUsuario.Focus()
    End Sub

    Private Sub btnIngresar_Click_1(sender As Object, e As EventArgs) Handles btnIngresar.Click
        If txtUsuario.Text = "" Then
            MsgBox("Ingrese el Usuario", 16, "Dato obligatorio")
            txtUsuario.Focus()
            Exit Sub
        End If
        If txtClave.Text = "" Then
            MsgBox("Ingrese la contraseña", 16, "Dato obligatorio")
            txtClave.Focus()
            Exit Sub
        End If
        Dim clave As String
        clave = encriptar(txtClave.Text)
        Abrir()
        cmd.CommandText = "select * from usuario where nomusuario='" & txtUsuario.Text & "' and clave='" & encriptar(txtClave.Text) & "'"
        dr = cmd.ExecuteReader
        If dr.Read Then
            If dr("nivel") = "B" Then
                frmprincipal.btnProveedores.Enabled = False
                frmprincipal.btnCompras.Enabled = False
                'frmprincipal.btnu'.Enabled = False
            ElseIf dr("nivel") = "C" Then
                frmprincipal.btnProveedores.Enabled = False
                frmprincipal.btnCompras.Enabled = False
                frmprincipal.btnClientes.Enabled = False
                frmprincipal.btnVentas.Enabled = False
                frmprincipal.btnProductos.Enabled = False
            End If
            frmprincipal.lblnombre.Text = "Usuario:"
            frmprincipal.lblnom.Text = dr("nomcompleto")
            Cerrar()
            FrmBarra.Show()
            Me.Hide()
        Else
            MsgBox("Datos incorrectos", 16, "Acceso denegado")
            txtClave.Text = ""
            txtClave.Focus()
            Cerrar()
        End If
    End Sub
End Class