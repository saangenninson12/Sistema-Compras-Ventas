﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmcontenedor
    Inherits System.Windows.Forms.Form

    'Form reemplaza a Dispose para limpiar la lista de componentes.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Requerido por el Diseñador de Windows Forms
    Private components As System.ComponentModel.IContainer

    'NOTA: el Diseñador de Windows Forms necesita el siguiente procedimiento
    'Se puede modificar usando el Diseñador de Windows Forms.  
    'No lo modifique con el editor de código.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Me.GroupBox1 = New System.Windows.Forms.GroupBox()
        Me.btnCompras = New System.Windows.Forms.Button()
        Me.PictureBox1 = New System.Windows.Forms.PictureBox()
        Me.GroupBox2 = New System.Windows.Forms.GroupBox()
        Me.PictureBox2 = New System.Windows.Forms.PictureBox()
        Me.btnVentas = New System.Windows.Forms.Button()
        Me.GroupBox3 = New System.Windows.Forms.GroupBox()
        Me.btnListadoventas = New System.Windows.Forms.Button()
        Me.PictureBox3 = New System.Windows.Forms.PictureBox()
        Me.GroupBox4 = New System.Windows.Forms.GroupBox()
        Me.btnListadocompras = New System.Windows.Forms.Button()
        Me.PictureBox4 = New System.Windows.Forms.PictureBox()
        Me.pnContenedor = New System.Windows.Forms.Panel()
        Me.GroupBox5 = New System.Windows.Forms.GroupBox()
        Me.Button1 = New System.Windows.Forms.Button()
        Me.PictureBox5 = New System.Windows.Forms.PictureBox()
        Me.GroupBox6 = New System.Windows.Forms.GroupBox()
        Me.ptUsuarios = New System.Windows.Forms.PictureBox()
        Me.ptLugar = New System.Windows.Forms.PictureBox()
        Me.ptCategoria = New System.Windows.Forms.PictureBox()
        Me.ptComprobante = New System.Windows.Forms.PictureBox()
        Me.ToolTip1 = New System.Windows.Forms.ToolTip(Me.components)
        Me.GroupBox1.SuspendLayout()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.GroupBox2.SuspendLayout()
        CType(Me.PictureBox2, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.GroupBox3.SuspendLayout()
        CType(Me.PictureBox3, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.GroupBox4.SuspendLayout()
        CType(Me.PictureBox4, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.GroupBox5.SuspendLayout()
        CType(Me.PictureBox5, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.GroupBox6.SuspendLayout()
        CType(Me.ptUsuarios, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.ptLugar, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.ptCategoria, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.ptComprobante, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'GroupBox1
        '
        Me.GroupBox1.BackColor = System.Drawing.Color.Lime
        Me.GroupBox1.Controls.Add(Me.btnCompras)
        Me.GroupBox1.Controls.Add(Me.PictureBox1)
        Me.GroupBox1.Font = New System.Drawing.Font("Century Gothic", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.GroupBox1.ForeColor = System.Drawing.Color.Maroon
        Me.GroupBox1.Location = New System.Drawing.Point(12, 12)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Size = New System.Drawing.Size(174, 204)
        Me.GroupBox1.TabIndex = 2
        Me.GroupBox1.TabStop = False
        Me.GroupBox1.Text = "Detalle Compras"
        '
        'btnCompras
        '
        Me.btnCompras.BackColor = System.Drawing.Color.DodgerBlue
        Me.btnCompras.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnCompras.ForeColor = System.Drawing.Color.FromArgb(CType(CType(37, Byte), Integer), CType(CType(46, Byte), Integer), CType(CType(59, Byte), Integer))
        Me.btnCompras.Location = New System.Drawing.Point(6, 169)
        Me.btnCompras.Name = "btnCompras"
        Me.btnCompras.Size = New System.Drawing.Size(162, 29)
        Me.btnCompras.TabIndex = 2
        Me.btnCompras.Text = "VER DETALLE"
        Me.btnCompras.UseVisualStyleBackColor = False
        '
        'PictureBox1
        '
        Me.PictureBox1.BackgroundImage = Global.InventarioVEVO.My.Resources.Resources.detalle_compra
        Me.PictureBox1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.PictureBox1.Location = New System.Drawing.Point(6, 22)
        Me.PictureBox1.Name = "PictureBox1"
        Me.PictureBox1.Size = New System.Drawing.Size(162, 144)
        Me.PictureBox1.TabIndex = 1
        Me.PictureBox1.TabStop = False
        '
        'GroupBox2
        '
        Me.GroupBox2.BackColor = System.Drawing.Color.Lime
        Me.GroupBox2.Controls.Add(Me.PictureBox2)
        Me.GroupBox2.Controls.Add(Me.btnVentas)
        Me.GroupBox2.Font = New System.Drawing.Font("Century Gothic", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.GroupBox2.ForeColor = System.Drawing.Color.Maroon
        Me.GroupBox2.Location = New System.Drawing.Point(372, 12)
        Me.GroupBox2.Name = "GroupBox2"
        Me.GroupBox2.Size = New System.Drawing.Size(174, 204)
        Me.GroupBox2.TabIndex = 3
        Me.GroupBox2.TabStop = False
        Me.GroupBox2.Text = "Detalle Ventas"
        '
        'PictureBox2
        '
        Me.PictureBox2.BackgroundImage = Global.InventarioVEVO.My.Resources.Resources.detalle_venta
        Me.PictureBox2.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.PictureBox2.Location = New System.Drawing.Point(6, 24)
        Me.PictureBox2.Name = "PictureBox2"
        Me.PictureBox2.Size = New System.Drawing.Size(162, 141)
        Me.PictureBox2.TabIndex = 3
        Me.PictureBox2.TabStop = False
        '
        'btnVentas
        '
        Me.btnVentas.BackColor = System.Drawing.Color.DodgerBlue
        Me.btnVentas.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnVentas.ForeColor = System.Drawing.Color.FromArgb(CType(CType(37, Byte), Integer), CType(CType(46, Byte), Integer), CType(CType(59, Byte), Integer))
        Me.btnVentas.Location = New System.Drawing.Point(6, 169)
        Me.btnVentas.Name = "btnVentas"
        Me.btnVentas.Size = New System.Drawing.Size(162, 29)
        Me.btnVentas.TabIndex = 2
        Me.btnVentas.Text = "VER DETALLE"
        Me.btnVentas.UseVisualStyleBackColor = False
        '
        'GroupBox3
        '
        Me.GroupBox3.BackColor = System.Drawing.Color.Aquamarine
        Me.GroupBox3.Controls.Add(Me.btnListadoventas)
        Me.GroupBox3.Controls.Add(Me.PictureBox3)
        Me.GroupBox3.Font = New System.Drawing.Font("Century Gothic", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.GroupBox3.ForeColor = System.Drawing.Color.Maroon
        Me.GroupBox3.Location = New System.Drawing.Point(552, 12)
        Me.GroupBox3.Name = "GroupBox3"
        Me.GroupBox3.Size = New System.Drawing.Size(174, 204)
        Me.GroupBox3.TabIndex = 4
        Me.GroupBox3.TabStop = False
        Me.GroupBox3.Text = "Listado Ventas"
        '
        'btnListadoventas
        '
        Me.btnListadoventas.BackColor = System.Drawing.Color.DodgerBlue
        Me.btnListadoventas.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnListadoventas.ForeColor = System.Drawing.Color.FromArgb(CType(CType(37, Byte), Integer), CType(CType(46, Byte), Integer), CType(CType(59, Byte), Integer))
        Me.btnListadoventas.Location = New System.Drawing.Point(6, 169)
        Me.btnListadoventas.Name = "btnListadoventas"
        Me.btnListadoventas.Size = New System.Drawing.Size(162, 29)
        Me.btnListadoventas.TabIndex = 2
        Me.btnListadoventas.Text = "VER DETALLE"
        Me.btnListadoventas.UseVisualStyleBackColor = False
        '
        'PictureBox3
        '
        Me.PictureBox3.BackgroundImage = Global.InventarioVEVO.My.Resources.Resources.listado_venta
        Me.PictureBox3.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.PictureBox3.Location = New System.Drawing.Point(6, 22)
        Me.PictureBox3.Name = "PictureBox3"
        Me.PictureBox3.Size = New System.Drawing.Size(162, 144)
        Me.PictureBox3.TabIndex = 1
        Me.PictureBox3.TabStop = False
        '
        'GroupBox4
        '
        Me.GroupBox4.BackColor = System.Drawing.Color.Aquamarine
        Me.GroupBox4.Controls.Add(Me.btnListadocompras)
        Me.GroupBox4.Controls.Add(Me.PictureBox4)
        Me.GroupBox4.Font = New System.Drawing.Font("Century Gothic", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.GroupBox4.ForeColor = System.Drawing.Color.Maroon
        Me.GroupBox4.Location = New System.Drawing.Point(192, 12)
        Me.GroupBox4.Name = "GroupBox4"
        Me.GroupBox4.Size = New System.Drawing.Size(174, 204)
        Me.GroupBox4.TabIndex = 5
        Me.GroupBox4.TabStop = False
        Me.GroupBox4.Text = "Listado Compras"
        '
        'btnListadocompras
        '
        Me.btnListadocompras.BackColor = System.Drawing.Color.DodgerBlue
        Me.btnListadocompras.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnListadocompras.ForeColor = System.Drawing.Color.FromArgb(CType(CType(37, Byte), Integer), CType(CType(46, Byte), Integer), CType(CType(59, Byte), Integer))
        Me.btnListadocompras.Location = New System.Drawing.Point(6, 169)
        Me.btnListadocompras.Name = "btnListadocompras"
        Me.btnListadocompras.Size = New System.Drawing.Size(162, 29)
        Me.btnListadocompras.TabIndex = 2
        Me.btnListadocompras.Text = "VER DETALLE"
        Me.btnListadocompras.UseVisualStyleBackColor = False
        '
        'PictureBox4
        '
        Me.PictureBox4.BackgroundImage = Global.InventarioVEVO.My.Resources.Resources.listado_compra
        Me.PictureBox4.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.PictureBox4.Location = New System.Drawing.Point(6, 22)
        Me.PictureBox4.Name = "PictureBox4"
        Me.PictureBox4.Size = New System.Drawing.Size(162, 144)
        Me.PictureBox4.TabIndex = 1
        Me.PictureBox4.TabStop = False
        '
        'pnContenedor
        '
        Me.pnContenedor.BackColor = System.Drawing.Color.White
        Me.pnContenedor.Location = New System.Drawing.Point(1, 222)
        Me.pnContenedor.Name = "pnContenedor"
        Me.pnContenedor.Size = New System.Drawing.Size(1144, 549)
        Me.pnContenedor.TabIndex = 6
        '
        'GroupBox5
        '
        Me.GroupBox5.BackColor = System.Drawing.Color.Lime
        Me.GroupBox5.Controls.Add(Me.Button1)
        Me.GroupBox5.Controls.Add(Me.PictureBox5)
        Me.GroupBox5.Font = New System.Drawing.Font("Century Gothic", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.GroupBox5.ForeColor = System.Drawing.Color.Maroon
        Me.GroupBox5.Location = New System.Drawing.Point(732, 12)
        Me.GroupBox5.Name = "GroupBox5"
        Me.GroupBox5.Size = New System.Drawing.Size(174, 204)
        Me.GroupBox5.TabIndex = 5
        Me.GroupBox5.TabStop = False
        Me.GroupBox5.Text = "Consulta General"
        '
        'Button1
        '
        Me.Button1.BackColor = System.Drawing.Color.DodgerBlue
        Me.Button1.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Button1.ForeColor = System.Drawing.Color.FromArgb(CType(CType(37, Byte), Integer), CType(CType(46, Byte), Integer), CType(CType(59, Byte), Integer))
        Me.Button1.Location = New System.Drawing.Point(6, 169)
        Me.Button1.Name = "Button1"
        Me.Button1.Size = New System.Drawing.Size(162, 29)
        Me.Button1.TabIndex = 2
        Me.Button1.Text = "VER DETALLE"
        Me.Button1.UseVisualStyleBackColor = False
        '
        'PictureBox5
        '
        Me.PictureBox5.BackgroundImage = Global.InventarioVEVO.My.Resources.Resources.consulta_general
        Me.PictureBox5.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.PictureBox5.Location = New System.Drawing.Point(6, 22)
        Me.PictureBox5.Name = "PictureBox5"
        Me.PictureBox5.Size = New System.Drawing.Size(162, 144)
        Me.PictureBox5.TabIndex = 1
        Me.PictureBox5.TabStop = False
        '
        'GroupBox6
        '
        Me.GroupBox6.BackColor = System.Drawing.Color.Aquamarine
        Me.GroupBox6.Controls.Add(Me.ptUsuarios)
        Me.GroupBox6.Controls.Add(Me.ptLugar)
        Me.GroupBox6.Controls.Add(Me.ptCategoria)
        Me.GroupBox6.Controls.Add(Me.ptComprobante)
        Me.GroupBox6.Font = New System.Drawing.Font("Microsoft MHei", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.GroupBox6.ForeColor = System.Drawing.Color.Maroon
        Me.GroupBox6.Location = New System.Drawing.Point(912, 12)
        Me.GroupBox6.Name = "GroupBox6"
        Me.GroupBox6.Size = New System.Drawing.Size(174, 204)
        Me.GroupBox6.TabIndex = 6
        Me.GroupBox6.TabStop = False
        Me.GroupBox6.Text = "Mantenimiento"
        '
        'ptUsuarios
        '
        Me.ptUsuarios.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(128, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.ptUsuarios.BackgroundImage = Global.InventarioVEVO.My.Resources.Resources.usuario
        Me.ptUsuarios.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.ptUsuarios.Location = New System.Drawing.Point(5, 22)
        Me.ptUsuarios.Name = "ptUsuarios"
        Me.ptUsuarios.Size = New System.Drawing.Size(81, 87)
        Me.ptUsuarios.TabIndex = 5
        Me.ptUsuarios.TabStop = False
        Me.ToolTip1.SetToolTip(Me.ptUsuarios, "USUARIOS")
        '
        'ptLugar
        '
        Me.ptLugar.BackColor = System.Drawing.Color.Yellow
        Me.ptLugar.BackgroundImage = Global.InventarioVEVO.My.Resources.Resources.lugar
        Me.ptLugar.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.ptLugar.Location = New System.Drawing.Point(88, 111)
        Me.ptLugar.Name = "ptLugar"
        Me.ptLugar.Size = New System.Drawing.Size(81, 87)
        Me.ptLugar.TabIndex = 4
        Me.ptLugar.TabStop = False
        Me.ToolTip1.SetToolTip(Me.ptLugar, "LUGARES")
        '
        'ptCategoria
        '
        Me.ptCategoria.BackColor = System.Drawing.Color.Red
        Me.ptCategoria.BackgroundImage = Global.InventarioVEVO.My.Resources.Resources.categoria
        Me.ptCategoria.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.ptCategoria.Location = New System.Drawing.Point(88, 22)
        Me.ptCategoria.Name = "ptCategoria"
        Me.ptCategoria.Size = New System.Drawing.Size(81, 87)
        Me.ptCategoria.TabIndex = 3
        Me.ptCategoria.TabStop = False
        Me.ToolTip1.SetToolTip(Me.ptCategoria, "CATEGORÍAS")
        '
        'ptComprobante
        '
        Me.ptComprobante.BackColor = System.Drawing.Color.FromArgb(CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer))
        Me.ptComprobante.BackgroundImage = Global.InventarioVEVO.My.Resources.Resources.comprobante
        Me.ptComprobante.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.ptComprobante.Location = New System.Drawing.Point(5, 111)
        Me.ptComprobante.Name = "ptComprobante"
        Me.ptComprobante.Size = New System.Drawing.Size(81, 87)
        Me.ptComprobante.TabIndex = 2
        Me.ptComprobante.TabStop = False
        Me.ToolTip1.SetToolTip(Me.ptComprobante, "COMPROBANTES")
        '
        'frmcontenedor
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.White
        Me.ClientSize = New System.Drawing.Size(1097, 742)
        Me.Controls.Add(Me.GroupBox6)
        Me.Controls.Add(Me.GroupBox5)
        Me.Controls.Add(Me.GroupBox4)
        Me.Controls.Add(Me.pnContenedor)
        Me.Controls.Add(Me.GroupBox3)
        Me.Controls.Add(Me.GroupBox2)
        Me.Controls.Add(Me.GroupBox1)
        Me.Name = "frmcontenedor"
        Me.Text = "frmcontenedor"
        Me.GroupBox1.ResumeLayout(False)
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.GroupBox2.ResumeLayout(False)
        CType(Me.PictureBox2, System.ComponentModel.ISupportInitialize).EndInit()
        Me.GroupBox3.ResumeLayout(False)
        CType(Me.PictureBox3, System.ComponentModel.ISupportInitialize).EndInit()
        Me.GroupBox4.ResumeLayout(False)
        CType(Me.PictureBox4, System.ComponentModel.ISupportInitialize).EndInit()
        Me.GroupBox5.ResumeLayout(False)
        CType(Me.PictureBox5, System.ComponentModel.ISupportInitialize).EndInit()
        Me.GroupBox6.ResumeLayout(False)
        CType(Me.ptUsuarios, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.ptLugar, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.ptCategoria, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.ptComprobante, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents PictureBox1 As System.Windows.Forms.PictureBox
    Friend WithEvents GroupBox1 As System.Windows.Forms.GroupBox
    Friend WithEvents btnCompras As System.Windows.Forms.Button
    Friend WithEvents GroupBox2 As System.Windows.Forms.GroupBox
    Friend WithEvents btnVentas As System.Windows.Forms.Button
    Friend WithEvents GroupBox3 As System.Windows.Forms.GroupBox
    Friend WithEvents btnListadoventas As System.Windows.Forms.Button
    Friend WithEvents PictureBox3 As System.Windows.Forms.PictureBox
    Friend WithEvents GroupBox4 As System.Windows.Forms.GroupBox
    Friend WithEvents btnListadocompras As System.Windows.Forms.Button
    Friend WithEvents PictureBox4 As System.Windows.Forms.PictureBox
    Friend WithEvents PictureBox2 As System.Windows.Forms.PictureBox
    Friend WithEvents pnContenedor As System.Windows.Forms.Panel
    Friend WithEvents GroupBox5 As System.Windows.Forms.GroupBox
    Friend WithEvents Button1 As System.Windows.Forms.Button
    Friend WithEvents PictureBox5 As System.Windows.Forms.PictureBox
    Friend WithEvents GroupBox6 As System.Windows.Forms.GroupBox
    Friend WithEvents ptComprobante As System.Windows.Forms.PictureBox
    Friend WithEvents ptUsuarios As System.Windows.Forms.PictureBox
    Friend WithEvents ptLugar As System.Windows.Forms.PictureBox
    Friend WithEvents ptCategoria As System.Windows.Forms.PictureBox
    Friend WithEvents ToolTip1 As System.Windows.Forms.ToolTip
End Class
