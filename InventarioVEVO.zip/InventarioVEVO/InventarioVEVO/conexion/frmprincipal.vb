﻿Imports System.Runtime.InteropServices
Public Class frmprincipal
    <DllImport("user32.DLL", EntryPoint:="ReleaseCapture")>
    Private Shared Sub ReleaseCapture()
    End Sub

    <DllImport("user32.DLL", EntryPoint:="SendMessage")>
    Private Shared Sub SendMessage(ByVal hWnd As System.IntPtr, ByVal wMsg As Integer, ByVal wParam As Integer, ByVal lParam As Integer)
    End Sub

    Private Sub PanelCabecera_MouseMove(sender As Object, e As MouseEventArgs) Handles PanelCabecera.MouseMove
        ReleaseCapture()
        SendMessage(Me.Handle, &H112&, &HF012&, 0)

    End Sub

    Private Sub AbrirFormEnPanel(ByVal Formhijo As Object)

        If Me.PanelContenedor.Controls.Count > 0 Then Me.PanelContenedor.Controls.RemoveAt(0)
        Dim fh As Form = TryCast(Formhijo, Form)
        fh.TopLevel = False
        fh.FormBorderStyle = FormBorderStyle.None
        fh.Dock = DockStyle.Fill
        Me.PanelContenedor.Controls.Add(fh)
        Me.PanelContenedor.Tag = fh
        fh.Show()

    End Sub

    Private Sub tmOCULTAR_Tick(sender As Object, e As EventArgs) Handles tmOCULTAR.Tick
        If Panel1.Width <= 60 Then
            Me.tmOCULTAR.Enabled = False
        Else
            Me.Panel1.Width = Panel1.Width - 20
        End If
    End Sub

    Private Sub tmMOSTRAR_Tick(sender As Object, e As EventArgs) Handles tmMOSTRAR.Tick
        If Panel1.Width >= 220 Then
            Me.tmMOSTRAR.Enabled = False
        Else
            Me.Panel1.Width = Panel1.Width + 20
        End If
    End Sub

    Private Sub btnMenu_Click(sender As Object, e As EventArgs) Handles btnMenu.Click
        If Panel1.Width = 220 Then
            tmOCULTAR.Enabled = True
        ElseIf Panel1.Width = 60 Then
            tmMOSTRAR.Enabled = True
        End If
    End Sub

    Private Sub btnCerrar_Click(sender As Object, e As EventArgs) Handles btnCerrar.Click
        Dim Cancel As Integer
        If (MsgBox("¿Esta seguro de salir sin guardar los cambios en los formularios?", vbCritical + vbYesNo) = vbYes) Then
            End
        Else
            Cancel = 1
        End If
    End Sub

    Private Sub PictureBox5_Click(sender As Object, e As EventArgs) Handles ptLogo.Click
        AbrirFormEnPanel(New frmcontenedor)
        'btnAjustes.PerformClick()
    End Sub

    Private Sub btnEmpleados_Click(sender As Object, e As EventArgs) Handles btnProveedores.Click
        AbrirFormEnPanel(New frmproveedor)
    End Sub

    Private Sub btnClientes_Click(sender As Object, e As EventArgs) Handles btnClientes.Click
        AbrirFormEnPanel(New frmcliente)
    End Sub

    Private Sub btnProductos_Click(sender As Object, e As EventArgs) Handles btnProductos.Click
        AbrirFormEnPanel(New frmarticulo)
    End Sub

    Private Sub btnVentas_Click(sender As Object, e As EventArgs) Handles btnVentas.Click
        AbrirFormEnPanel(New frmventas)
    End Sub

    Private Sub btnCompras_Click(sender As Object, e As EventArgs) Handles btnCompras.Click
        AbrirFormEnPanel(New frmcompras)
    End Sub

    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        AbrirFormEnPanel(New frmcontenedor)
    End Sub

    Private Sub btnAjustes_Click(sender As Object, e As EventArgs) Handles btnAjustes.Click
        AbrirFormEnPanel(New frm_backup_base)
    End Sub
End Class
