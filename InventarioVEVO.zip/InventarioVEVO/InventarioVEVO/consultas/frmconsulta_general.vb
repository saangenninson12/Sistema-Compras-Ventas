﻿Public Class frmconsulta_general
    Sub titulo()
        dgventas.ColumnCount = 0
        dgventas.Columns.Add("codtipocomprobante", "Codigo")
        dgventas.Columns.Add("num", "Nº")
        dgventas.Columns.Add("serie", "Serie")
        dgventas.Columns.Add("numero", "Número")
        dgventas.Columns.Add("fecha", "Fecha")
        dgventas.Columns.Add("codcliente", "ID Cliente")
        dgventas.Columns.Add("dni", "Dni")
        dgventas.Columns.Add("ruc", "Ruc")
        dgventas.Columns.Add("cliente", "Cliente")
        dgventas.Columns.Add("direccion", "Dirección")
        dgventas.Columns.Add("total", "Total")

        dgventas.Columns("codtipocomprobante").Width = 40
        dgventas.Columns("num").Width = 30
        dgventas.Columns("fecha").Width = 80
        dgventas.Columns("codcliente").Width = 50
        dgventas.Columns("serie").Width = 40
        dgventas.Columns("Numero").Width = 70
        dgventas.Columns("dni").Width = 70
        dgventas.Columns("ruc").Width = 100
        dgventas.Columns("cliente").Width = 200
        dgventas.Columns("direccion").Width = 200
        dgventas.Columns("total").Width = 70

        dgventas.Columns("Num").DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter
        dgventas.Columns("fecha").DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter
        dgventas.Columns("codcliente").DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter
        dgventas.Columns("serie").DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter
        dgventas.Columns("Numero").DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter
        dgventas.Columns("dni").DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter
        dgventas.Columns("ruc").DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter
        dgventas.Columns("total").DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight
        dgventas.Columns("codtipocomprobante").Visible = False
    End Sub
    Sub titulo1()
        dgCompras.ColumnCount = 0
        dgCompras.Columns.Add("codtipocomprobante", "Codigo")
        dgCompras.Columns.Add("num", "Nº")
        dgCompras.Columns.Add("serie", "Serie")
        dgCompras.Columns.Add("numero", "Número")
        dgCompras.Columns.Add("fecha", "Fecha")
        dgCompras.Columns.Add("codproveedor", "ID Proveedor")
        dgCompras.Columns.Add("dniruc", "Dni/Ruc")
        dgCompras.Columns.Add("razonsocial", "Razón Social")
        dgCompras.Columns.Add("direccion", "Direccion")
        dgCompras.Columns.Add("total", "Total")


        dgCompras.Columns("codproveedor").Width = 40
        dgCompras.Columns("razonsocial").Width = 250
        dgCompras.Columns("codtipocomprobante").Width = 40
        dgCompras.Columns("num").Width = 30
        dgCompras.Columns("serie").Width = 40
        dgCompras.Columns("Numero").Width = 70
        dgCompras.Columns("total").Width = 70

        dgCompras.Columns("Num").DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter
        dgCompras.Columns("serie").DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter
        dgCompras.Columns("codproveedor").DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter
        dgCompras.Columns("Numero").DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter
        dgCompras.Columns("total").DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight
        dgCompras.Columns("codtipocomprobante").Visible = False
    End Sub
    Private Sub btnVer_Click(sender As Object, e As EventArgs) Handles btnVer.Click
        lblNombres.Visible = True
        lblNombres.Text = "Seleccione los botones que están a la izquierda como por ejemplo Ventas o Compras, Aviso"


        If rbVentas.Checked Then
            lblNombres.Text = "Listado de Ventas"
            txtrsocial.Enabled = False
            txtdni.Enabled = True
            dgCompras.Visible = False
            dgventas.Visible = True
            titulo()
            Abrir()
            cmd.CommandText = "select * from ventas_V"
            dr = cmd.ExecuteReader
            While dr.Read
                dgventas.Rows.Add(dr("codtipocomprobante"), dgventas.RowCount + 1, dr("serie"), dr("numero"), Format(dr("fecha"), "dd-MM-yyyy"), dr("codcliente"), dr("dni"), dr("ruc"), dr("cliente"), dr("direccion"), Format(dr("total"), "##0.00"))
            End While
            Cerrar()
        End If

        If rbCompras.Checked Then
            lblNombres.Text = "Listado de Compras"
            txtrsocial.Enabled = True
            txtdni.Enabled = False
            dgCompras.Visible = True
            dgventas.Visible = False
            titulo1()
            Abrir()
            cmd.CommandText = "select * from compras_V"
            dr = cmd.ExecuteReader
            While dr.Read
                dgCompras.Rows.Add(dr("codtipocomprobante"), dgCompras.RowCount + 1, dr("serie"), dr("numero"), Format(dr("fecha"), "dd-MM-yyyy"), dr("codproveedor"), dr("dniruc"), dr("razonsocial"), dr("direccion"), Format(dr("total"), "##0.00"))
            End While
            Cerrar()
        End If
    End Sub

    Private Sub txtdni_KeyPress(sender As Object, e As KeyPressEventArgs) Handles txtdni.KeyPress
        If Asc(e.KeyChar) = 13 Then
            titulo()
            Abrir()
            cmd.CommandText = "select * from ventas_V where dni like '%" & txtdni.Text & "%'"
            dr = cmd.ExecuteReader
            While dr.Read
                dgventas.Rows.Add(dr("codtipocomprobante"), dgventas.RowCount + 1, dr("serie"), dr("numero"), Format(dr("fecha"), "dd-MM-yyyy"), dr("codcliente"), dr("dni"), dr("ruc"), dr("cliente"), dr("direccion"), Format(dr("total"), "##0.00"))
            End While
            Cerrar()
        End If
    End Sub

    Private Sub txtrsocial_KeyPress(sender As Object, e As KeyPressEventArgs) Handles txtrsocial.KeyPress
        titulo1()
        Abrir()
        cmd.CommandText = "select * from compras_V where razonsocial like '%" & txtrsocial.Text & "%'"
        dr = cmd.ExecuteReader
        While dr.Read
            dgCompras.Rows.Add(dr("codtipocomprobante"), dgCompras.RowCount + 1, dr("serie"), dr("numero"), Format(dr("fecha"), "dd-MM-yyyy"), dr("codproveedor"), dr("dniruc"), dr("razonsocial"), dr("direccion"), Format(dr("total"), "##0.00"))
        End While
        Cerrar()
    End Sub

    Private Sub rbCompras_CheckedChanged(sender As Object, e As EventArgs) Handles rbCompras.CheckedChanged
        'falta arregla para que muestre con las fechas
        'titulo1()
        'Abrir()
        'cmd.CommandText = "select * from compras_V where fecha = '" & dtInicio.Value & "'" And "'" & dtFin.Value & "'"
        'dr = cmd.ExecuteReader
        'While dr.Read
        '    dgCompras.Rows.Add(dr("codtipocomprobante"), dgCompras.RowCount + 1, dr("serie"), dr("numero"), Format(dr("fecha"), "dd-MM-yyyy"), dr("codproveedor"), dr("dniruc"), dr("razonsocial"), dr("direccion"), Format(dr("total"), "##0.00"))
        'End While
        'Cerrar()
    End Sub
End Class