﻿Public Class frmlistado_ventas
    Sub titulo()
        dg.ColumnCount = 0
        dg.Columns.Add("codtipocomprobante", "Codigo")
        dg.Columns.Add("num", "Nº")
        dg.Columns.Add("serie", "Serie")
        dg.Columns.Add("numero", "Número")
        dg.Columns.Add("fecha", "Fecha")
        dg.Columns.Add("codcliente", "ID Cliente")
        dg.Columns.Add("dni", "Dni")
        dg.Columns.Add("ruc", "Ruc")
        dg.Columns.Add("cliente", "Cliente")
        dg.Columns.Add("direccion", "Dirección")
        dg.Columns.Add("total", "Total")

        dg.Columns("codtipocomprobante").Width = 40
        dg.Columns("num").Width = 30
        dg.Columns("fecha").Width = 100
        dg.Columns("codcliente").Width = 50
        dg.Columns("serie").Width = 50
        dg.Columns("Numero").Width = 90
        dg.Columns("dni").Width = 90
        dg.Columns("ruc").Width = 120
        dg.Columns("cliente").Width = 220
        dg.Columns("direccion").Width = 200
        dg.Columns("total").Width = 90

        dg.Columns("Num").DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter
        dg.Columns("fecha").DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter
        dg.Columns("codcliente").DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter
        dg.Columns("serie").DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter
        dg.Columns("Numero").DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter
        dg.Columns("dni").DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter
        dg.Columns("ruc").DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter
        dg.Columns("total").DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight
        dg.Columns("codtipocomprobante").Visible = False
    End Sub
    Sub mostrar()
        titulo()
        Abrir()
        cmd.CommandText = "select * from ventas_V"
        dr = cmd.ExecuteReader
        While dr.Read
            dg.Rows.Add(dr("codtipocomprobante"), dg.RowCount + 1, dr("serie"), dr("numero"), Format(dr("fecha"), "dd-MM-yyyy"), dr("codcliente"), dr("dni"), dr("ruc"), dr("cliente"), dr("direccion"), Format(dr("total"), "##0.00"))
        End While
        Cerrar()
    End Sub
    Private Sub frmconsulta_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        mostrar()
    End Sub

    Private Sub btnexcel_Click(sender As Object, e As EventArgs) Handles btnexcel.Click
        'Creamos las variables
        Dim exApp As New Microsoft.Office.Interop.Excel.Application
        Dim exLibro As Microsoft.Office.Interop.Excel.Workbook
        Dim exHoja As Microsoft.Office.Interop.Excel.Worksheet
        Try
            'Añadimos el Libro al programa, y la hoja al libro
            exLibro = exApp.Workbooks.Add
            exHoja = exLibro.Worksheets.Add()

            ' ¿Cuantas columnas y cuantas filas?
            Dim NCol As Integer = dg.ColumnCount
            Dim NRow As Integer = dg.RowCount

            'Aqui recorremos todas las filas, y por cada fila todas las columnas y vamos escribiendo.
            For i As Integer = 1 To NCol
                exHoja.Cells.Item(1, i) = dg.Columns(i - 1).Name.ToString
                exHoja.Cells.Item(1, i).HorizontalAlignment = 3
            Next

            For Fila As Integer = 0 To NRow - 1
                For Col As Integer = 0 To NCol - 1
                    exHoja.Cells.Item(Fila + 2, Col + 1) = dg.Rows(Fila).Cells(Col).Value
                Next
            Next
            'Titulo en negrita, Alineado al centro y que el tamaño de la columna se ajuste al texto
            exHoja.Rows.Item(1).Font.Bold = 1
            exHoja.Rows.Item(1).HorizontalAlignment = 3
            exHoja.Columns.AutoFit()


            'Aplicación visible
            exApp.Application.Visible = True

            exHoja = Nothing
            exLibro = Nothing
            exApp = Nothing

        Catch ex As Exception
            MsgBox(ex.Message, MsgBoxStyle.Critical, "Error al exportar a Excel")
        End Try
    End Sub
End Class