﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmconsulta_general
    Inherits System.Windows.Forms.Form

    'Form reemplaza a Dispose para limpiar la lista de componentes.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Requerido por el Diseñador de Windows Forms
    Private components As System.ComponentModel.IContainer

    'NOTA: el Diseñador de Windows Forms necesita el siguiente procedimiento
    'Se puede modificar usando el Diseñador de Windows Forms.  
    'No lo modifique con el editor de código.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim DataGridViewCellStyle1 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle2 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Me.dgCompras = New System.Windows.Forms.DataGridView()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.dtInicio = New System.Windows.Forms.DateTimePicker()
        Me.dtFin = New System.Windows.Forms.DateTimePicker()
        Me.rbCompras = New System.Windows.Forms.RadioButton()
        Me.rbVentas = New System.Windows.Forms.RadioButton()
        Me.lblNombres = New System.Windows.Forms.Label()
        Me.btnVer = New System.Windows.Forms.Button()
        Me.txtrsocial = New System.Windows.Forms.TextBox()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.dgventas = New System.Windows.Forms.DataGridView()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.txtdni = New System.Windows.Forms.TextBox()
        CType(Me.dgCompras, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.dgventas, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'dgCompras
        '
        Me.dgCompras.AllowUserToAddRows = False
        Me.dgCompras.AllowUserToDeleteRows = False
        Me.dgCompras.BackgroundColor = System.Drawing.Color.White
        Me.dgCompras.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.dgCompras.Location = New System.Drawing.Point(12, 127)
        Me.dgCompras.Name = "dgCompras"
        Me.dgCompras.ReadOnly = True
        DataGridViewCellStyle1.Font = New System.Drawing.Font("Microsoft MHei", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.dgCompras.RowsDefaultCellStyle = DataGridViewCellStyle1
        Me.dgCompras.Size = New System.Drawing.Size(793, 305)
        Me.dgCompras.TabIndex = 2
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Font = New System.Drawing.Font("Microsoft YaHei", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.Location = New System.Drawing.Point(138, 22)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(33, 20)
        Me.Label1.TabIndex = 3
        Me.Label1.Text = "De:"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Font = New System.Drawing.Font("Microsoft YaHei", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label2.Location = New System.Drawing.Point(138, 49)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(54, 20)
        Me.Label2.TabIndex = 4
        Me.Label2.Text = "Hasta:"
        '
        'dtInicio
        '
        Me.dtInicio.Font = New System.Drawing.Font("Microsoft YaHei", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.dtInicio.Format = System.Windows.Forms.DateTimePickerFormat.[Short]
        Me.dtInicio.Location = New System.Drawing.Point(201, 17)
        Me.dtInicio.Name = "dtInicio"
        Me.dtInicio.Size = New System.Drawing.Size(127, 27)
        Me.dtInicio.TabIndex = 5
        '
        'dtFin
        '
        Me.dtFin.Font = New System.Drawing.Font("Microsoft YaHei", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.dtFin.Format = System.Windows.Forms.DateTimePickerFormat.[Short]
        Me.dtFin.Location = New System.Drawing.Point(201, 47)
        Me.dtFin.Name = "dtFin"
        Me.dtFin.Size = New System.Drawing.Size(127, 27)
        Me.dtFin.TabIndex = 6
        '
        'rbCompras
        '
        Me.rbCompras.AutoSize = True
        Me.rbCompras.Font = New System.Drawing.Font("Microsoft YaHei", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.rbCompras.Location = New System.Drawing.Point(20, 20)
        Me.rbCompras.Name = "rbCompras"
        Me.rbCompras.Size = New System.Drawing.Size(92, 24)
        Me.rbCompras.TabIndex = 7
        Me.rbCompras.TabStop = True
        Me.rbCompras.Text = "Compras"
        Me.rbCompras.UseVisualStyleBackColor = True
        '
        'rbVentas
        '
        Me.rbVentas.AutoSize = True
        Me.rbVentas.Font = New System.Drawing.Font("Microsoft YaHei", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.rbVentas.Location = New System.Drawing.Point(20, 43)
        Me.rbVentas.Name = "rbVentas"
        Me.rbVentas.Size = New System.Drawing.Size(76, 24)
        Me.rbVentas.TabIndex = 8
        Me.rbVentas.TabStop = True
        Me.rbVentas.Text = "Ventas"
        Me.rbVentas.UseVisualStyleBackColor = True
        '
        'lblNombres
        '
        Me.lblNombres.AutoSize = True
        Me.lblNombres.Font = New System.Drawing.Font("Microsoft YaHei", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblNombres.Location = New System.Drawing.Point(370, 104)
        Me.lblNombres.Name = "lblNombres"
        Me.lblNombres.Size = New System.Drawing.Size(69, 20)
        Me.lblNombres.TabIndex = 9
        Me.lblNombres.Text = "Listados"
        Me.lblNombres.Visible = False
        '
        'btnVer
        '
        Me.btnVer.BackColor = System.Drawing.Color.Transparent
        Me.btnVer.Font = New System.Drawing.Font("Microsoft YaHei", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnVer.Image = Global.InventarioVEVO.My.Resources.Resources.ver
        Me.btnVer.Location = New System.Drawing.Point(741, 30)
        Me.btnVer.Name = "btnVer"
        Me.btnVer.Size = New System.Drawing.Size(33, 31)
        Me.btnVer.TabIndex = 12
        Me.btnVer.UseVisualStyleBackColor = False
        '
        'txtrsocial
        '
        Me.txtrsocial.Font = New System.Drawing.Font("Microsoft YaHei", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtrsocial.Location = New System.Drawing.Point(510, 17)
        Me.txtrsocial.Name = "txtrsocial"
        Me.txtrsocial.Size = New System.Drawing.Size(213, 27)
        Me.txtrsocial.TabIndex = 13
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Font = New System.Drawing.Font("Microsoft YaHei", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label4.Location = New System.Drawing.Point(341, 20)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(163, 20)
        Me.Label4.TabIndex = 14
        Me.Label4.Text = "Buscar x Razón Social"
        '
        'dgventas
        '
        Me.dgventas.AllowUserToAddRows = False
        Me.dgventas.AllowUserToDeleteRows = False
        Me.dgventas.BackgroundColor = System.Drawing.Color.White
        Me.dgventas.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.dgventas.Location = New System.Drawing.Point(12, 127)
        Me.dgventas.Name = "dgventas"
        Me.dgventas.ReadOnly = True
        DataGridViewCellStyle2.Font = New System.Drawing.Font("Microsoft MHei", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.dgventas.RowsDefaultCellStyle = DataGridViewCellStyle2
        Me.dgventas.Size = New System.Drawing.Size(793, 305)
        Me.dgventas.TabIndex = 15
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Font = New System.Drawing.Font("Microsoft YaHei", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label3.Location = New System.Drawing.Point(341, 52)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(114, 20)
        Me.Label3.TabIndex = 17
        Me.Label3.Text = "Buscar por Dni"
        '
        'txtdni
        '
        Me.txtdni.Font = New System.Drawing.Font("Microsoft YaHei", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtdni.Location = New System.Drawing.Point(510, 49)
        Me.txtdni.Name = "txtdni"
        Me.txtdni.Size = New System.Drawing.Size(213, 27)
        Me.txtdni.TabIndex = 16
        '
        'frmconsulta_general
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.White
        Me.ClientSize = New System.Drawing.Size(817, 444)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.txtdni)
        Me.Controls.Add(Me.dgventas)
        Me.Controls.Add(Me.Label4)
        Me.Controls.Add(Me.txtrsocial)
        Me.Controls.Add(Me.btnVer)
        Me.Controls.Add(Me.lblNombres)
        Me.Controls.Add(Me.rbVentas)
        Me.Controls.Add(Me.rbCompras)
        Me.Controls.Add(Me.dtFin)
        Me.Controls.Add(Me.dtInicio)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.dgCompras)
        Me.Name = "frmconsulta_general"
        Me.Text = ".:. Consulta General .:."
        CType(Me.dgCompras, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.dgventas, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents dgCompras As System.Windows.Forms.DataGridView
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents dtInicio As System.Windows.Forms.DateTimePicker
    Friend WithEvents dtFin As System.Windows.Forms.DateTimePicker
    Friend WithEvents rbCompras As System.Windows.Forms.RadioButton
    Friend WithEvents rbVentas As System.Windows.Forms.RadioButton
    Friend WithEvents lblNombres As System.Windows.Forms.Label
    Friend WithEvents btnVer As System.Windows.Forms.Button
    Friend WithEvents txtrsocial As System.Windows.Forms.TextBox
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents dgventas As System.Windows.Forms.DataGridView
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents txtdni As System.Windows.Forms.TextBox
End Class
