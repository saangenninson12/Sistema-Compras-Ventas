﻿Public Class frmlistado_compras
    Sub Listado()
        dg.ColumnCount = 0
        dg.Columns.Add("codigo", "ID")
        dg.Columns.Add("codtipocomprobante", "Codigo")
        dg.Columns.Add("num", "Nº")
        dg.Columns.Add("serie", "Serie")
        dg.Columns.Add("numero", "Número")
        dg.Columns.Add("nick", "Nick  ")
        dg.Columns.Add("razonsocial", "Razón Social")
        dg.Columns.Add("nombre", "Nombre Artículo")
        dg.Columns.Add("costo", "Costo")
        dg.Columns.Add("cantidad", "Cantidad")
        dg.Columns.Add("preciopublico", "Precio Público")
        dg.Columns.Add("Importe", "Importe")

        dg.Columns("codigo").Width = 40
        dg.Columns("nick").Width = 40
        dg.Columns("razonsocial").Width = 210
        dg.Columns("nombre").Width = 250
        dg.Columns("codtipocomprobante").Width = 50
        dg.Columns("num").Width = 40
        dg.Columns("serie").Width = 60
        dg.Columns("Numero").Width = 90
        dg.Columns("importe").Width = 90
        dg.Columns("preciopublico").Width = 90
        dg.Columns("cantidad").Width = 70

        dg.Columns("Num").DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter
        dg.Columns("serie").DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter
        dg.Columns("nick").DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter
        dg.Columns("Numero").DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter
        dg.Columns("cantidad").DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight
        dg.Columns("costo").DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight
        dg.Columns("importe").DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight
        dg.Columns("preciopublico").DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight
        dg.Columns("codtipocomprobante").Visible = False
        dg.Columns("codigo").Visible = False


        Abrir()
        cmd.CommandText = "select * from comprasdetalle_V"
        dr = cmd.ExecuteReader
        While dr.Read
            dg.Rows.Add(dr("codigo"), dr("codtipocomprobante"), dg.RowCount + 1, dr("serie"), dr("numero"), dr("nick"), dr("razonsocial"), dr("nombre"), Format(dr("costo"), "##0.00"), Val(dr("cantidad")), Format(dr("preciopublico"), "##0.00"), Format(dr("importe"), "##0.00"))
        End While
        Cerrar()
    End Sub

    Private Sub listadocompras_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Listado()
    End Sub

    Private Sub btnexcel_Click(sender As Object, e As EventArgs) Handles btnexcel.Click
        'Creamos las variables
        Dim exApp As New Microsoft.Office.Interop.Excel.Application
        Dim exLibro As Microsoft.Office.Interop.Excel.Workbook
        Dim exHoja As Microsoft.Office.Interop.Excel.Worksheet
        Try
            'Añadimos el Libro al programa, y la hoja al libro
            exLibro = exApp.Workbooks.Add
            exHoja = exLibro.Worksheets.Add()

            ' ¿Cuantas columnas y cuantas filas?
            Dim NCol As Integer = dg.ColumnCount
            Dim NRow As Integer = dg.RowCount

            'Aqui recorremos todas las filas, y por cada fila todas las columnas y vamos escribiendo.
            For i As Integer = 1 To NCol
                exHoja.Cells.Item(1, i) = dg.Columns(i - 1).Name.ToString
                exHoja.Cells.Item(1, i).HorizontalAlignment = 3
            Next

            For Fila As Integer = 0 To NRow - 1
                For Col As Integer = 0 To NCol - 1
                    exHoja.Cells.Item(Fila + 2, Col + 1) = dg.Rows(Fila).Cells(Col).Value
                Next
            Next
            'Titulo en negrita, Alineado al centro y que el tamaño de la columna se ajuste al texto
            exHoja.Rows.Item(1).Font.Bold = 1
            exHoja.Rows.Item(1).HorizontalAlignment = 3
            exHoja.Columns.AutoFit()


            'Aplicación visible
            exApp.Application.Visible = True

            exHoja = Nothing
            exLibro = Nothing
            exApp = Nothing

        Catch ex As Exception
            MsgBox(ex.Message, MsgBoxStyle.Critical, "Error al exportar a Excel")
        End Try
    End Sub
End Class