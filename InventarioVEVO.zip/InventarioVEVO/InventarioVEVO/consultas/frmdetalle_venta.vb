﻿Public Class frmdetalle_venta
    Sub limpiar()
        TxtSerie.Text = ""
        TxtNumero.Text = ""
        TxtSerie.Focus()
    End Sub
    Sub Totalizar()
        Dim Total As Decimal
        Dim N As Integer
        For N = 0 To Dg.RowCount - 1
            Total = Total + Val(Dg.Rows(N).Cells("Importe").Value)
        Next
        LblTotal.Text = Format(Total, "###,##0.00")
    End Sub

    Sub Titulo()
        Dg.ColumnCount = 0
        Dg.Columns.Add("Codigo", "Codigo")
        Dg.Columns.Add("Costo", "Costo")
        Dg.Columns.Add("PrecioOficial", "PrecioOficial")
        Dg.Columns.Add("Numero", "Nº")
        Dg.Columns.Add("Cantidad", "Cantidad")
        Dg.Columns.Add("Descripcion", "Descripcion")
        Dg.Columns.Add("Precio", "Precio")
        Dg.Columns.Add("Importe", "Importe")
        Dg.Columns("Numero").Width = 30
        Dg.Columns("Cantidad").Width = 90
        Dg.Columns("Descripcion").Width = 250
        Dg.Columns("Importe").Width = 100
        Dg.Columns("Precio").Width = 100
        Dg.Columns("Numero").DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter
        Dg.Columns("Cantidad").DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter
        Dg.Columns("Precio").DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight
        Dg.Columns("Importe").DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight

        Dg.Columns("Codigo").Visible = False
        Dg.Columns("Costo").Visible = False
        Dg.Columns("PrecioOficial").Visible = False

        LblTotal.Text = "0.00"
    End Sub
    Private Sub frmconsultar_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Titulo()
    End Sub

    Private Sub BtnBuscar_Click(sender As Object, e As EventArgs) Handles BtnBuscar.Click
        If TxtSerie.Text = "" Then
            MsgBox("Ingrese la Serie", 16, "Dato para buscar")
            TxtSerie.Focus()
            Exit Sub
        End If
        If TxtNumero.Text = "" Then
            MsgBox("Ingrese el Número", 16, "Dato para buscar")
            TxtNumero.Focus()
            Exit Sub
        End If
        Abrir()
        cmd.CommandText = "Select * From Ventas_V Where Serie='" & TxtSerie.Text & "' And Numero='" & TxtNumero.Text & "'"
        dr = cmd.ExecuteReader
        If dr.Read Then
            LblFecha.Text = Format(dr("Fecha"), "dd-MM-yyy")
            LblSerie.Text = dr("Serie")
            LblNumero.Text = dr("Numero")
            LblCliente.Text = dr("Cliente")
            LblDireccion.Text = dr("Direccion")
            dr.Close()
            'Muestra el detalle
            cmd.CommandText = "Select * From VentasDetalle_V  Where Serie='" & TxtSerie.Text & "' And Numero='" & TxtNumero.Text & "'"
            dr = cmd.ExecuteReader
            While dr.Read
                Dg.Rows.Add(dr("CodArticulo"), dr("Costo"), dr("PrecioOficial"), Dg.RowCount + 1, Format(dr("Cantidad"), "##0.00"), dr("Nombre"), Format(dr("PrecioVenta"), "##0.00"), Format(dr("Importe"), "##0.00"))
            End While
        Else
            MsgBox("El comprobante no existe", 16, "Aviso")
        End If
        Cerrar()
        limpiar()
        Totalizar()
    End Sub

    Private Sub TxtSerie_KeyPress(sender As Object, e As KeyPressEventArgs) Handles TxtSerie.KeyPress
        If Asc(e.KeyChar) = 13 Then
            TxtNumero.Focus()
        End If
    End Sub

    Private Sub TxtNumero_KeyPress(sender As Object, e As KeyPressEventArgs) Handles TxtNumero.KeyPress
        If Asc(e.KeyChar) = 13 Then
            BtnBuscar.Focus()
        End If
    End Sub

    Private Sub PrintDocument1_PrintPage(sender As Object, e As Printing.PrintPageEventArgs) Handles PrintDocument1.PrintPage
        e.Graphics.DrawImage(PicBoleta.Image, 1, 1, 855, 1085)
        Dim x, y As Integer

        x = 90
        y = 370

        e.Graphics.DrawString(LblFecha.Text, New Font("Arial Rounded MT Bold", 18, FontStyle.Regular), Brushes.Black, 102, 164)
        e.Graphics.DrawString(LblSerie.Text, New Font("Bernard MT Condensed", 20, FontStyle.Regular), Brushes.Red, 535, 160)
        e.Graphics.DrawString(LblNumero.Text, New Font("Bernard MT Condensed", 20, FontStyle.Regular), Brushes.Red, 620, 160)
        e.Graphics.DrawString(LblCliente.Text, New Font("Arial", 15, FontStyle.Regular), Brushes.Blue, 230, 235)
        e.Graphics.DrawString(LblDireccion.Text, New Font("Arial", 15, FontStyle.Regular), Brushes.Blue, 230, 280)

        e.Graphics.DrawString(Dg.CurrentRow.Cells("numero").Value, New Font("Arial", 12, FontStyle.Regular), Brushes.White, 90, 370)
        e.Graphics.DrawString(Dg.CurrentRow.Cells("cantidad").Value, New Font("Arial", 12, FontStyle.Regular), Brushes.Black, 158, 370)
        e.Graphics.DrawString(Dg.CurrentRow.Cells("descripcion").Value, New Font("Arial", 12, FontStyle.Regular), Brushes.Black, 250, 370)
        e.Graphics.DrawString(Dg.CurrentRow.Cells("precio").Value, New Font("Arial", 12, FontStyle.Regular), Brushes.Black, 640, 370)
        e.Graphics.DrawString(Dg.CurrentRow.Cells("importe").Value, New Font("Arial", 12, FontStyle.Regular), Brushes.Black, 710, 370)
        e.Graphics.DrawString(LblTotal.Text, New Font("Arial", 12, FontStyle.Regular), Brushes.Black, 700, 1010)


        '_________________________________________

        'e.Graphics.DrawImage(PicBoleta.Image, 50, 52, 500, 1000)
        'Dim x, y As Integer

        'x = 98
        'y = 221

        'e.Graphics.DrawString("", New Font("Console", 14, FontStyle.Bold), Brushes.Black, 100, 100)
        'e.Graphics.DrawString("======================", New Font("Console", 14, FontStyle.Bold), Brushes.Black, 100, 122)
        'e.Graphics.DrawString("==**", New Font("Arial", 10, FontStyle.Bold), Brushes.Black, 160, 154)
        'e.Graphics.DrawString(LblCliente.Text, New Font("Arial", 10, FontStyle.Bold), Brushes.Black, 160, 175)
        'e.Graphics.DrawString(LblDireccion.Text, New Font("Arial", 10, FontStyle.Bold), Brushes.Black, 160, 195)
        'e.Graphics.DrawString("**", New Font("Arial", 12, FontStyle.Bold), Brushes.Black, 620, 95)
        'e.Graphics.DrawString(LblFecha.Text, New Font("Arial", 14, FontStyle.Bold), Brushes.Black, 600, 119)
        'e.Graphics.DrawString(LblSerie.Text, New Font("Arial", 14, FontStyle.Bold), Brushes.Black, x + 460, 145)
        'e.Graphics.DrawString(LblNumero.Text, New Font("Arial", 14, FontStyle.Bold), Brushes.Black, x + 530, 145)
        'y = y + 10
        'For i = 0 To Dg.Rows.Count - 1
        '    e.Graphics.DrawString(Me.Dg.Rows(i).Cells(0).Value, New Font("Arial", 8, FontStyle.Bold), Brushes.Black, x, y)
        '    e.Graphics.DrawString(Me.Dg.Rows(i).Cells(4).Value, New Font("Arial", 8, FontStyle.Bold), Brushes.Black, x + 65, y)
        '    e.Graphics.DrawString(Me.Dg.Rows(i).Cells(1).Value, New Font("Arial", 8, FontStyle.Bold), Brushes.Black, x + 140, y)
        '    e.Graphics.DrawString(Me.Dg.Rows(i).Cells(3).Value, New Font("Arial", 8, FontStyle.Bold), Brushes.Black, x + 468, y)
        '    e.Graphics.DrawString(Me.Dg.Rows(i).Cells(9).Value, New Font("Arial", 8, FontStyle.Bold), Brushes.Black, x + 200, y)
        '    y = y + 19
        'Next
        'e.Graphics.DrawString("S/. " & LblTotal.Text, New Font("Arial", 10, FontStyle.Bold), Brushes.Black, x + 560, 1002)
    End Sub

    Private Sub BtnImprimir_Click(sender As Object, e As EventArgs) Handles BtnImprimir.Click
        PrintDocument1.Print()
    End Sub

    Private Sub TxtSerie_Click(sender As Object, e As EventArgs) Handles TxtSerie.Click
        limpiar()
        Titulo()
    End Sub
End Class