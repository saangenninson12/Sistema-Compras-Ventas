﻿Public Class frmventas
    Dim IGVP As Decimal
    Sub SoloNumeros(ByRef e As System.Windows.Forms.KeyPressEventArgs)
        If Char.IsDigit(e.KeyChar) Then
            e.Handled = False
        ElseIf Char.IsControl(e.KeyChar) Then
            e.Handled = False
        Else
            e.Handled = True
            MsgBox("Solo se puede ingresar valores de tipo número", MsgBoxStyle.Exclamation, "Ingreso de Número")
        End If
    End Sub
    Sub Limpiar()
        LblCodigo.Text = ""
        TxtNombre.Text = ""
        LblCategoria.Text = ""
        TxtCosto.Text = ""
        TxtPrecio.Text = ""
        TxtStock.Text = ""
    End Sub

    Sub Totalizar()
        Dim Total, IGV, SubTotal As Decimal
        Dim N As Integer
        For N = 0 To Dg.RowCount - 1
            Total = Total + CDbl(Dg.Rows(N).Cells("Importe").Value)
        Next
        'Calcula el IGV
        IGV = Math.Round(Total * IGVP / (100 + IGVP), 2)
        SubTotal = Total - IGV
        lblsubtotal.Text = Format(SubTotal, "###,##0.00")
        lbligv.Text = Format(IGV, "###,##0.00")
        LblTotal.Text = Format(Total, "###,##0.00")
    End Sub

    Sub Titulo()
        Dg.ColumnCount = 0
        'Títulos
        Dg.Columns.Add("Codigo", "Codigo")
        Dg.Columns.Add("Costo", "Costo")
        Dg.Columns.Add("PrecioOficial", "PrecioOficial")
        Dg.Columns.Add("Numero", "Nº")
        Dg.Columns.Add("Cantidad", "Cantidad")
        Dg.Columns.Add("Descripcion", "Descripcion")
        Dg.Columns.Add("Precio", "Precio")
        Dg.Columns.Add("Importe", "Importe")
        'Dimensión
        Dg.Columns("Numero").Width = 40
        Dg.Columns("Cantidad").Width = 90
        Dg.Columns("Descripcion").Width = 300
        Dg.Columns("Importe").Width = 100
        Dg.Columns("Precio").Width = 100
        Dg.Columns("Numero").DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter
        Dg.Columns("Cantidad").DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter
        Dg.Columns("Precio").DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight
        Dg.Columns("Importe").DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight

        Dg.Columns("Codigo").Visible = False
        Dg.Columns("Costo").Visible = False
        Dg.Columns("PrecioOficial").Visible = False

        lbligv.Text = "0.00"
        lblsubtotal.Text = "0.00"
        LblTotal.Text = "0.00"
    End Sub

    Sub MostrarNombres()
        CboArticulos.Items.Clear()
        Abrir()
        cmd.CommandText = "Select Nombre From Articulos Order By Nombre"
        dr = cmd.ExecuteReader
        While dr.Read
            CboArticulos.Items.Add(dr("Nombre"))
        End While
        Cerrar()
    End Sub

    Sub MostrarClientes()
        cboclientes.Items.Clear()
        Abrir()
        cmd.CommandText = "Select Nombre From Clientes_V Order By Nombre"
        dr = cmd.ExecuteReader
        While dr.Read
            cboclientes.Items.Add(dr("Nombre"))
        End While
        Cerrar()
        cboclientes.Text = "CLIENTES VARIOS"
    End Sub
    Sub MostrarComprobantes()
        CboComprobantes.Items.Clear()
        Abrir()
        cmd.CommandText = "Select Nombre From Comprobantes Where Estado='A' Order By Nombre"
        dr = cmd.ExecuteReader
        While dr.Read
            CboComprobantes.Items.Add(dr("Nombre"))
        End While
        Cerrar()
    End Sub
    Sub ventasrealizadas()
        dgvista.ColumnCount = 0
        dgvista.Columns.Add("serie", "Serie")
        dgvista.Columns.Add("numero", "Numero")

        dgvista.Columns("serie").Width = 55
        dgvista.Columns("numero").Width = 95

        dgvista.Columns("serie").DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter
        dgvista.Columns("numero").DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter

        Abrir()
        cmd.CommandText = "select serie,numero from ventas_V where fecha='" & DtFecha.Text & "'"
        dr = cmd.ExecuteReader
        While dr.Read
            dgvista.Rows.Add(dr("serie"), dr("numero"))
        End While
        Cerrar()
    End Sub

    Private Sub frmventas_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Abrir()
        cmd.CommandText = "select igv from configuracion"
        dr = cmd.ExecuteReader
        If dr.Read Then
            IGVP = dr("IGV")
        Else
            IGVP = 0
        End If
        Cerrar()
        MostrarComprobantes()
        MostrarNombres()
        MostrarClientes()
        Titulo()
    End Sub

    Sub NumeroComprobante()
        Abrir()
        cmd.CommandText = "Select Serie,Numero From Comprobantes Where Nombre='" & CboComprobantes.Text & "'"
        dr = cmd.ExecuteReader
        If dr.Read Then
            LblSerie.Text = dr("Serie")
            LblNumero.Text = Format(dr("Numero"), "00000000")
        Else
            LblSerie.Text = ""
            LblNumero.Text = ""
        End If
        Cerrar()
    End Sub

    Private Sub CboComprobantes_SelectedIndexChanged(sender As Object, e As EventArgs) Handles CboComprobantes.SelectedIndexChanged
        NumeroComprobante()
    End Sub

    Private Sub CboArticulos_KeyPress(sender As Object, e As KeyPressEventArgs) Handles CboArticulos.KeyPress
        If Asc(e.KeyChar) = 13 Then
            TxtCantidad.Focus()
        End If
    End Sub

    Private Sub CboArticulos_SelectedIndexChanged(sender As Object, e As EventArgs) Handles CboArticulos.SelectedIndexChanged
        Abrir()
        cmd.CommandText = "Select * From Articulos_V Where Nombre='" & CboArticulos.Text & "'"
        dr = cmd.ExecuteReader
        If dr.Read Then
            LblCodigo.Text = dr("Codigo")
            TxtNombre.Text = dr("Nombre")
            LblCategoria.Text = dr("Categoria")
            TxtCosto.Text = Format(dr("Costo"), "##0.00")
            TxtPrecio.Text = Format(dr("Precio"), "##0.00")
            TxtPrecioVenta.Text = Format(dr("Precio"), "##0.00")
            TxtStock.Text = dr("Stock")
        Else
            Limpiar()
        End If
        Cerrar()
    End Sub

    Private Sub TxtPrecioVenta_KeyPress(sender As Object, e As KeyPressEventArgs) Handles TxtPrecioVenta.KeyPress
        'Tabla Original que envia los datos.
        If Asc(e.KeyChar) = 13 Then
            If Val(TxtCantidad.Text) > Val(TxtStock.Text) Then
                MsgBox("No hay stock suficiente", 16, "Verifique")
                Exit Sub
            End If
            Dg.Rows.Add(LblCodigo.Text, TxtCosto.Text, TxtPrecio.Text, Dg.RowCount + 1, Val(TxtCantidad.Text), TxtNombre.Text, Format(Val(TxtPrecioVenta.Text), "##0.00"), LblImporte.Text)
            'Tabla para poder modificar los datos de la venta.
            Totalizar()
            TxtCantidad.Text = ""
            CboArticulos.Focus()
        End If
    End Sub

    Private Sub TxtPrecioVenta_TextChanged(sender As Object, e As EventArgs) Handles TxtPrecioVenta.TextChanged
        LblImporte.Text = Format(Val(TxtCantidad.Text) * Val(TxtPrecioVenta.Text), "###,##0.00")
    End Sub

    Private Sub TxtCantidad_KeyPress(sender As Object, e As KeyPressEventArgs) Handles TxtCantidad.KeyPress
        If Asc(e.KeyChar) = 13 Then
            TxtPrecioVenta.Focus()
        End If
        SoloNumeros(e)
    End Sub

    Private Sub TxtCantidad_TextChanged(sender As Object, e As EventArgs) Handles TxtCantidad.TextChanged
        LblImporte.Text = Format(Val(TxtCantidad.Text) * Val(TxtPrecioVenta.Text), "###,##.00")
    End Sub

    Private Sub Dg_CellEndEdit(sender As Object, e As DataGridViewCellEventArgs) Handles Dg.CellEndEdit
        If Dg.CurrentRow.Cells("Cantidad").Value = 0 Then
            Dg.Rows.Remove(Dg.CurrentRow)
        Else
            Dg.CurrentRow.Cells("Importe").Value = Format(Val(Dg.CurrentRow.Cells("Cantidad").Value) * Val(Dg.CurrentRow.Cells("Precio").Value), "###,##0.00")
        End If
        Totalizar()
    End Sub

    Private Sub BtnGrabar_Click(sender As Object, e As EventArgs) Handles BtnGrabar.Click
            If CboComprobantes.Text = "" Then
                MsgBox("Seleccione el tipo de comprobante", 16, "No se puede grabar")
                Exit Sub
            End If

            If Dg.RowCount = 0 Then
                MsgBox("No ha registrado ningun artículo", 16, "No se puede grabar")
                Exit Sub
            End If

            If cboclientes.Text = "" Then
                MsgBox("Seleccione el cliente", 16, "No se puede grabar")
                Exit Sub
            End If

            If CboComprobantes.Text = "FACTURA" And cboclientes.Text = "CLIENTES VARIOS" Then
                MsgBox("Seleccione un cliente con RUC", 16, "No se puede grabar")
                Exit Sub
            End If
            If CboComprobantes.Text = "FACTURA" And Len(txtdocumento.Text) <> 11 Then
                MsgBox("El cliente debe tener RUC", 16, "No se puede grabar")
                Exit Sub
            End If

            Dim CodTipoComprobante As String
            Dim CodCliente As Integer
            Abrir()
            cmd.CommandText = "Select Codigo From Comprobantes Where Nombre='" & CboComprobantes.Text & "'"
            dr = cmd.ExecuteReader
            If dr.Read Then
                CodTipoComprobante = dr("Codigo")
                dr.Close()
            Else
                Cerrar()
                MsgBox("El tipo de comprobante no existe", 16, "Verifique")
                Exit Sub
            End If
            cmd.CommandText = "Select Codigo From Clientes_V Where Nombre='" & cboclientes.Text & "'"
            dr = cmd.ExecuteReader
            If dr.Read Then
                CodCliente = dr("Codigo")
                dr.Close()
            Else
                Cerrar()
                MsgBox("El cliente no existe", 16, "Verifique")
                Exit Sub
            End If
            Dim N As Integer
            'Graba los datos principales de la venta
            cmd.CommandText = "Insert Into Ventas (CodTipoComprobante,Serie,Numero,Fecha,CodCliente,Estado)" _
                & "Values ('" & CodTipoComprobante & "','" & lblSerie.Text & "','" & lblNumero.Text & "','" & Format(DtFecha.Value, "dd-MM-yyyy") & "'," & CodCliente & ",'A')"
            cmd.ExecuteNonQuery()
            'Graba el detalle de la venta
            For N = 0 To Dg.RowCount - 1
                cmd.CommandText = "Insert Into VentasDetalle (CodTipoComprobante,Serie,Numero,CodArticulo,Costo,PrecioOficial,PrecioVenta,Cantidad)" _
                    & "Values ('" & CodTipoComprobante & "','" & lblSerie.Text & "','" & lblNumero.Text & "','" & Dg.Rows(N).Cells("Codigo").Value & "'," _
                    & "'" & Dg.Rows(N).Cells("Costo").Value & "','" & Dg.Rows(N).Cells("PrecioOficial").Value & "','" & Dg.Rows(N).Cells("Precio").Value & "','" & Dg.Rows(N).Cells("Cantidad").Value & "')"
                cmd.ExecuteNonQuery()
                'Actualiza el stock del articulo
                cmd.CommandText = "Update Articulos Set Stock=Stock - " & Val(Dg.Rows(N).Cells("Cantidad").Value) _
                    & " Where Codigo=" & Val(Dg.Rows(N).Cells("Codigo").Value)
                cmd.ExecuteNonQuery()
            Next
            'Actualiza el numero del comprobante
            cmd.CommandText = "Update Comprobantes Set Numero = Numero + 1 Where Codigo='" & CodTipoComprobante & "'"
            cmd.ExecuteNonQuery()
            Cerrar()
            MsgBox("La venta se registró correctamente", 64, "Aviso")
            txtdocumento.Text = ""
            cboclientes.Text = "CLIENTES VARIOS"
            NumeroComprobante()
        Titulo()
        'Limpiar
        CboComprobantes.Text = ""
        lblSerie.Text = ""
        lblNumero.Text = ""
        TxtNombre.Text = ""
        LblCodigo.Text = ""
        LblCategoria.Text = ""
        TxtCosto.Text = ""
        TxtCantidad.Text = ""
        TxtPrecioVenta.Text = ""
        TxtPrecio.Text = ""
        TxtStock.Text = ""
        LblImporte.Text = ""
        txtdocumento.Text = ""
        cboclientes.Text = ""
        lblsubtotal.Text = ""
        lbligv.Text = ""
        LblTotal.Text = ""
        Dg.ClearSelection()
    End Sub

    Private Sub cbocliente_SelectedIndexChanged(sender As Object, e As EventArgs) Handles cboclientes.SelectedIndexChanged
        If cboclientes.Focused Then
            Abrir()
            cmd.CommandText = "Select DNI,RUC From Clientes_V Where Nombre='" & cboclientes.Text & "'"
            dr = cmd.ExecuteReader
            If dr.Read Then
                If dr("DNI") = "" Then
                    txtdocumento.Text = dr("RUC")
                Else
                    txtdocumento.Text = dr("DNI")
                End If
            End If
            Cerrar()
        End If
    End Sub

    Private Sub txtdocumento_KeyPress(sender As Object, e As KeyPressEventArgs) Handles txtdocumento.KeyPress
        If Asc(e.KeyChar) = 13 Then
            Dim Documento As String
            If txtdocumento.TextLength = 8 Then
                Documento = "DNI"
            ElseIf txtdocumento.TextLength = 11 Then
                Documento = "RUC"
            Else
                MsgBox("cantidad de digitos", 32, "aviso")

            End If
            Abrir()
            cmd.CommandText = "Select * from Clientes_V Where " & Documento & "='" & txtdocumento.Text & "'"
            dr = cmd.ExecuteReader
            'Pregunta si existe
            If dr.Read() Then
                cboclientes.Text = dr("Nombre")
                Cerrar()
            Else
                Cerrar()
                If txtdocumento.TextLength = 8 Then
                    frmclientenuevo.TxtDni.Text = txtdocumento.Text
                Else
                    frmclientenuevo.TxtRuc.Text = txtdocumento.Text
                End If
                frmclientenuevo.ShowDialog()
            End If
            'dancito1998 clave de pc pilco
        End If
        SoloNumeros(e)
    End Sub

    Private Sub Label17_Click(sender As Object, e As EventArgs) Handles Label17.Click
        ventasrealizadas()
    End Sub

    Private Sub dgvista_DoubleClick(sender As Object, e As EventArgs) Handles dgvista.DoubleClick
        Dg.Rows.Clear()
        Abrir()
        cmd.CommandText = "Select * From Ventas_V Where Serie='" & dgvista.CurrentRow.Cells("serie").Value & "' And Numero='" & dgvista.CurrentRow.Cells("numero").Value & "'"
        dr = cmd.ExecuteReader
        If dr.Read Then
            'Para mostrar los datos del comprador (Cliente)
            txtdocumento.Text = dr("dni")
            cboclientes.Text = dr("cliente")
            dr.Close()
            cmd.CommandText = "select * from ventasdetalle_v where serie = '" & dgvista.CurrentRow.Cells("serie").Value & "' and numero = '" & dgvista.CurrentRow.Cells("numero").Value & "'"
            dr = cmd.ExecuteReader
            While dr.Read
                Dg.Rows.Add(dr("CodArticulo"), dr("Costo"), dr("PrecioOficial"), Dg.RowCount + 1, Format(dr("Cantidad"), "##0"), dr("Nombre"), Format(dr("PrecioVenta"), "######.00"), Format(dr("Importe"), "######.00"))
                Totalizar()
            End While
        Else
            MsgBox("El comprobante no existe", 16, "Aviso")
        End If
        Cerrar()
    End Sub

    Private Sub Dg_Click(sender As Object, e As EventArgs) Handles Dg.Click
        Abrir()
        cmd.CommandText = "Select * From Ventas_V Where Serie='" & dgvista.CurrentRow.Cells("serie").Value & "' And Numero='" & dgvista.CurrentRow.Cells("numero").Value & "'"
        dr = cmd.ExecuteReader
        If dr.Read Then
            'Muestra de Venta
            DtFecha.Text = dr("fecha")
            CboComprobantes.Text = dr("CodTipoComprobante")
            lblSerie.Text = dr("Serie")
            lblNumero.Text = dr("Numero")
            dr.Close()
            cmd.CommandText = "Select * From ventasdetalle_V Where Nombre='" & Dg.CurrentRow.Cells("Descripcion").Value & "'"
            dr = cmd.ExecuteReader
            If dr.Read Then
                LblCodigo.Text = dr("CodArticulo")
                TxtCosto.Text = dr("Costo")
                TxtPrecio.Text = dr("PrecioOficial")
                TxtCantidad.Text = dr("Cantidad")
                TxtNombre.Text = dr("Nombre")
                TxtPrecioVenta.Text = Format(dr("PrecioVenta"), "######.00")
                LblImporte.Text = Format(dr("Importe"), "######.00")
            End If
        End If
        Cerrar()
    End Sub
End Class