﻿Public Class frmcompras
    Sub Titulo()
        Dg.ColumnCount = 0
        Dg.Columns.Add("codigo", "codigo")
        Dg.Columns.Add("Numero", "Nº")
        Dg.Columns.Add("Cantidad", "Cantidad")
        Dg.Columns.Add("Descripcion", "Descripcion")
        Dg.Columns.Add("Costo", "Costo")
        Dg.Columns.Add("Precio", "Precio")
        Dg.Columns.Add("Importe", "Importe")

        Dg.Columns("codigo").Visible = False
        Dg.Columns("costo").Visible = False

        Dg.Columns("Numero").Width = 30
        Dg.Columns("Cantidad").Width = 70
        Dg.Columns("Descripcion").Width = 200
        Dg.Columns("Importe").Width = 70
        Dg.Columns("Importe").DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight

        'LblTotal.Text = "0.00"
    End Sub
    
    Sub MostrarComprobantes()
        CboComprobantes.Items.Clear()
        Abrir()
        cmd.CommandText = "Select Nombre From Comprobantes Where Estado='A' Order By Nombre"
        dr = cmd.ExecuteReader
        While dr.Read
            CboComprobantes.Items.Add(dr("Nombre"))
        End While
        Cerrar()
    End Sub
    Sub mostrarproductos()
        cboproductos.Items.Clear()
        Abrir()
        cmd.CommandText = "select * from articulos"
        dr = cmd.ExecuteReader
        While dr.Read
            cboproductos.Items.Add(dr("nombre"))
        End While
        Cerrar()
    End Sub
    Sub mostrarproveedores()
        cboproveedores.Items.Clear()
        Abrir()
        cmd.CommandText = "select RazonSocial From Proveedores Order By RazonSocial"
        dr = cmd.ExecuteReader
        While dr.Read
            cboproveedores.Items.Add(dr("RazonSocial"))
        End While
        Cerrar()
    End Sub
    Private Sub frmcompras_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        MostrarComprobantes()
        mostrarproductos()
        mostrarproveedores()
        Titulo()
    End Sub

    Private Sub CboComprobantes_SelectedIndexChanged(sender As Object, e As EventArgs) Handles CboComprobantes.SelectedIndexChanged
        Abrir()
        cmd.CommandText = "Select Serie,Numero From Comprobantes Where Nombre='" & CboComprobantes.Text & "'"
        dr = cmd.ExecuteReader
        If dr.Read Then
            txtSerie.Text = dr("Serie")
            txtNumero.Text = Format(dr("Numero"), "00000000")
        Else
            txtSerie.Text = ""
            txtNumero.Text = ""
        End If
        Cerrar()
    End Sub

    Private Sub cboproductos_SelectedIndexChanged(sender As Object, e As EventArgs) Handles cboproductos.SelectedIndexChanged
        Abrir()
        cmd.CommandText = "Select * From Articulos_V Where Nombre='" & cboproductos.Text & "'"
        dr = cmd.ExecuteReader
        If dr.Read Then
            LblCodigo.Text = dr("Codigo")
            txtNombres.Text = dr("Nombre")
            txtcosto.Text = Format(dr("Costo"), "##0.00")
            TxtCostocompra.Text = Format(dr("Costo"), "##0.00")
            txtprecio.Text = Format(dr("Precio"), "##0.00")
            txtstock.Text = Format(dr("Stock"), "##0.00")
        Else
            'Limpiar()
        End If
        Cerrar()
    End Sub
    Sub Totalizar()
        Dim Total As Decimal
        Dim N As Integer
        For N = 0 To Dg.RowCount - 1
            Total = Total + Val(Dg.Rows(N).Cells("Importe").Value)
        Next
        LblTotal.Text = Format(Total, "###,##0.00")
    End Sub

    Private Sub txtpreciooficial_KeyPress(sender As Object, e As KeyPressEventArgs) Handles txtpreciooficial.KeyPress
        If Asc(e.KeyChar) = 13 Then
            Dg.Rows.Add(LblCodigo.Text, Dg.RowCount + 1, Val(TxtCantidad.Text), txtNombres.Text, TxtCostocompra.Text, Val(txtpreciooficial.Text), lblimporte.Text)
            Totalizar()
            TxtCantidad.Text = ""
            cboproductos.Focus()
        End If
    End Sub

    Private Sub TxtCostocompra_KeyPress(sender As Object, e As KeyPressEventArgs) Handles TxtCostocompra.KeyPress
        If Asc(e.KeyChar) = 13 Then
            txtpreciooficial.Focus()
        End If
    End Sub

    Private Sub TxtCantidad_KeyPress(sender As Object, e As KeyPressEventArgs) Handles TxtCantidad.KeyPress
        If Asc(e.KeyChar) = 13 Then
            TxtCostocompra.Focus()
        End If
    End Sub

    Private Sub txtpreciooficial_TextChanged(sender As Object, e As EventArgs) Handles txtpreciooficial.TextChanged
        lblimporte.Text = Format(Val(TxtCantidad.Text) * Val(txtpreciooficial.Text), "###,##0.00")
    End Sub

    Private Sub btncomprar_Click(sender As Object, e As EventArgs) Handles btncomprar.Click
        If CboComprobantes.Text = "" Then
            MsgBox("Seleccione el tipo de comprobante", 16, "No se puede grabar")
            Exit Sub
        End If

        If Dg.RowCount = 0 Then
            MsgBox("No ha registrado ningun artículo", 16, "No se puede grabar")
            Exit Sub
        End If

        If cboproveedores.Text = "" Then
            MsgBox("Seleccione el cliente", 16, "No se puede grabar")
            Exit Sub
        End If

        Dim CodTipoComprobante As String
        Dim CodProveedor As Integer

        Abrir()
        cmd.CommandText = "Select Codigo From Comprobantes Where Nombre='" & CboComprobantes.Text & "'"
        dr = cmd.ExecuteReader
        If dr.Read Then
            CodTipoComprobante = dr("Codigo")
            dr.Close()
        Else
            Cerrar()
            MsgBox("El tipo de comprobante no existe", 16, "Verifique")
            Exit Sub
        End If

        cmd.CommandText = "Select Codigo From proveedores Where RazonSocial='" & cboproveedores.Text & "'"
        dr = cmd.ExecuteReader
        If dr.Read Then
            CodProveedor = dr("Codigo")
            dr.Close()
        Else
            Cerrar()
            MsgBox("El proveedor no existe", 16, "Verifique")
            Exit Sub
        End If

        Dim N As Integer
        'Graba los datos principales de la compra
        cmd.CommandText = "Insert Into compras (CodTipoComprobante,Serie,Numero,Codproveedor,Fecha,Estado)" _
            & "Values ('" & CodTipoComprobante & "','" & txtSerie.Text & "','" & txtNumero.Text & "','" & CodProveedor & "','" & Format(DtFecha.Value, "dd-MM-yyyy") & "','A')"
        cmd.ExecuteNonQuery()
        'Graba el detalle de la compra
        For N = 0 To Dg.RowCount - 1
            cmd.CommandText = "Insert Into ComprasDetalle (CodTipoComprobante,Serie,Numero,CodProveedor,CodArticulo,Costo,Cantidad,PrecioPublico)" _
                & "Values ('" & CodTipoComprobante & "','" & txtSerie.Text & "','" & txtNumero.Text & "','" & CodProveedor & "','" & Dg.Rows(N).Cells("Codigo").Value & "'," _
                & "'" & Dg.Rows(N).Cells("costo").Value & "','" & Dg.Rows(N).Cells("cantidad").Value & "','" & Dg.Rows(N).Cells("precio").Value & "')"
            cmd.ExecuteNonQuery()
            'Actualiza el stock del articulo
            cmd.CommandText = "Update Articulos Set Stock=Stock + " & Val(Dg.Rows(N).Cells("Cantidad").Value) & " Where Codigo=" & Val(Dg.Rows(N).Cells("Codigo").Value)
            cmd.ExecuteNonQuery()
        Next
        'Actualiza el numero del comprobante
        cmd.CommandText = "Update Comprobantes Set Numero = Numero + 1 Where Codigo='" & CodTipoComprobante & "'"
        cmd.ExecuteNonQuery()
        Cerrar()
        MsgBox("La Compra se registró correctamente", 64, "Aviso")

        MostrarComprobantes()
        Titulo()
    End Sub

    Private Sub Dg_CellEndEdit(sender As Object, e As DataGridViewCellEventArgs) Handles Dg.CellEndEdit
        If Dg.CurrentRow.Cells("Cantidad").Value = 0 Then
            Dg.Rows.Remove(Dg.CurrentRow)
        Else
            Dg.Rows.Add(LblCodigo.Text, Dg.RowCount + 1, Val(TxtCantidad.Text), txtNombres.Text, Format(Val(txtpreciooficial.Text), "###,##0.00"), lblimporte.Text)
        End If
        Totalizar()
    End Sub

    Private Sub btnBuscar_Click(sender As Object, e As EventArgs) Handles btnBuscar.Click
        If txtSerie.Text = "" Then
            MsgBox("Ingrese la Serie", 16, "Dato para buscar")
            txtSerie.Focus()
            Exit Sub
        End If
        If txtNumero.Text = "" Then
            MsgBox("Ingrese el Número", 16, "Dato para buscar")
            txtNumero.Focus()
            Exit Sub
        End If
        Abrir()
        cmd.CommandText = "Select * From compras_V Where Serie='" & txtSerie.Text & "' And Numero='" & txtNumero.Text & "'"
        dr = cmd.ExecuteReader
        If dr.Read Then
            lblFecha.Text = Format(dr("Fecha"), "dd-MM-yyy")
            lblSeries.Text = dr("Serie")
            lblNumeros.Text = dr("Numero")
            lblProveedor.Text = dr("razonsocial")
            lblComprobante.Text = CboComprobantes.Text
        End If

        dr.Close()
        'Muestra el detalle
        cmd.CommandText = "Select * From comprasDetalle_V  Where Serie='" & txtSerie.Text & "' And Numero='" & txtNumero.Text & "'"
        dr = cmd.ExecuteReader
        While dr.Read
            Dg.Rows.Add(dr("codigo"), Dg.RowCount + 1, Val(dr("cantidad")), dr("nombre"), dr("costo"), Format(dr("preciopublico"), "##0.00"), Format(dr("importe"), "##0.00"))
        End While

        dr.Close()
        cmd.CommandText = "Select * From comprasDetalle_V  Where Serie='" & txtSerie.Text & "' And Numero='" & txtNumero.Text & "'"
        dr = cmd.ExecuteReader
        While dr.Read
            'Dg1.Rows.Add(dr("codigo"), Dg.RowCount + 1, Format(dr("cantidad"), "###,##00.00"), dr("nombre"), Format(dr("preciopublico"), "###,##0.00"), dr("importe"))
        End While
        'limpiar()
        Totalizar()
    End Sub

End Class